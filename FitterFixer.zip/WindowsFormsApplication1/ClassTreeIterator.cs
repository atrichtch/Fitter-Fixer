﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;

namespace WindowsFormsApplication1
{
    class ClassTreeIterator
    {
        private ClassTreeNode current, prev;
        private int indOfCurr;
        private ArrayList subIters;
  //      private ArrayList path;
        public ClassTreeIterator(ClassTreeNode n)
        {
            current = n;
            indOfCurr = 0;
            subIters = new ArrayList();
            ArrayList children = n.getChildren();
            foreach (ClassTreeNode node in children)
            {
                subIters.Add(new ClassTreeIterator(node));
            }
        }
        public bool hasNext()
        {
            if (current.getChildren() == null) return false;
            foreach (ClassTreeIterator it in subIters)
                if (it.hasNext()) return true;
            if (prev == null) return false;
            System.Collections.IEnumerator en = prev.getChildren().GetEnumerator();
            if (indOfCurr < prev.getChildren().Count-1) return true;
            return false;
        }
        public ClassTreeNode next() {
            prev = current;
            foreach (ClassTreeIterator it in subIters)
                if (it.hasNext())
                {
                    current = it.next();
                    return current;
                }
            indOfCurr++;
            System.Collections.IEnumerator en = prev.getChildren().GetEnumerator();
            en.MoveNext();
            current=(ClassTreeNode)en.Current;
            return current;
        }
    }
}
