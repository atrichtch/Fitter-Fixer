﻿/*@author Alex Trichtchenko
 * Not for commercial use
 */

using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IBM.Data.DB2;
using IBM.Data.DB2Types;

namespace WindowsFormsApplication1
{
    public partial class CatErrSelect : Form
    {
        //ArrayList[] whoseErrs;
        DB2Connection db;
        String tblName;
        int[] catErrs;
        String[] attrs;
        String[] categMatches, categRefs;
        ArrayList lookupTbls;
        ArrayList lookupInfo;

        public CatErrSelect()
        {
            InitializeComponent();
        }

        public CatErrSelect(DB2Connection db, String tblName, int[] catErrs,
            String[] attrs, String[] categMatches, String[] categRefs)
        {
            InitializeComponent();
            this.db = db;
            this.tblName = tblName;
            this.catErrs = catErrs;
            this.attrs = attrs;
            lookupTbls = new ArrayList();
            lookupInfo = new ArrayList();
            this.categMatches = categMatches;
            this.categRefs = categRefs;
            for (int i = 0; i < attrs.Length; i++)
                comboBox1.Items.Add(attrs[i]);
            DataTable tmp = db.GetSchema(DB2MetaDataCollectionNames.Tables);
            foreach (DataRow dr in tmp.Rows)
            {
                if (!dr["table_schema"].ToString().StartsWith("SYS"))
                    listBox1.Items.Add(dr["table_name"]);
            }
        }

        public CatErrSelect(DB2Connection db, String tblName, String[] categErrs, String[] categMatches, String[] categRefs) {
            InitializeComponent();
            this.db = db;
            this.tblName = tblName;
            this.attrs = categErrs;
            lookupTbls = new ArrayList();
            lookupInfo = new ArrayList();
            this.categMatches = categMatches;
            this.categRefs = categRefs;
            for (int i = 0; i < attrs.Length; i++)
                comboBox1.Items.Add(attrs[i]);
            DataTable tmp = db.GetSchema(DB2MetaDataCollectionNames.Tables);
            foreach (DataRow dr in tmp.Rows)
            {
                if (!dr["table_schema"].ToString().StartsWith("SYS"))
                    listBox1.Items.Add(dr["table_name"]);
            }
            dataGridView1.AutoGenerateColumns = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem != null)
            {
                String[] curInfo = new String[3];
                curInfo[0] = listBox1.SelectedItem.ToString();
                this.lookupInfo.Add(curInfo);
                this.lookupTbls.Add(listBox1.SelectedItem.ToString());
                listBox2.Items.Add(listBox1.SelectedItem);
                //comboBox2.Items.Add(listBox1.SelectedItem);
                listBox1.Items.Remove(listBox1.SelectedItem);
            }
        }

        private void CatErrSelect_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Form8 f8 = new Form8(lookupTbls, db, tblName, catErrs[comboBox1.SelectedIndex], /*attrs,*/attrs[comboBox1.SelectedIndex], categMatches[comboBox1.SelectedIndex],categRefs[comboBox1.SelectedIndex]);
            Form8 f8 = new Form8(lookupTbls, db, tblName, comboBox1.SelectedIndex + 1, attrs[comboBox1.SelectedIndex], categMatches[comboBox1.SelectedIndex], categRefs[comboBox1.SelectedIndex]);
            Visible = false;
            if (f8.ShowDialog() == DialogResult.Cancel)
                Visible = true;
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem != null)
            {
                String[] curInfo = new String[3];
                curInfo[0] = listBox1.SelectedItem.ToString();
                this.lookupInfo.Add(curInfo);
                this.lookupTbls.Add(listBox1.SelectedItem.ToString());
                listBox2.Items.Add(listBox1.SelectedItem);
                //comboBox2.Items.Add(listBox1.SelectedItem);
                listBox1.Items.Remove(listBox1.SelectedItem);
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem != null)
            {
                DataTable dt = new DataTable();
                DB2DataAdapter ad = new DB2DataAdapter("select * from " + listBox1.SelectedItem.ToString() + " fetch first 10 rows only;", db);
                ad.Fill(dt);
                dataGridView1.DataSource = dt;
                dataGridView1.Refresh();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            FileDialog fd = new OpenFileDialog();
            fd.Filter = "Comma Separated Values|*.csv";
            String dataCSV = "";
            if (fd.ShowDialog() == DialogResult.OK)
            {
                dataCSV = fd.FileName.Split('\\').Last();
                CSVParser parser = new CSVParser();
                parser.parse(fd.FileName, db);
                listBox1.Items.Add(dataCSV.Substring(0, dataCSV.Length - 4));
            }
        }
    }
}
