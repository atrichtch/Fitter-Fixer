﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Data;
using System.Text;
using IBM.Data.DB2;

namespace WindowsFormsApplication1
{
    class WeightedApriori
    {
        DB2Connection database;
        String tableName;
        public WeightedApriori(DB2Connection db, String tblName, String[] attrs, ArrayList[] whoseErrs, String soughtAttr, int soughtErr, String matchTbl, int refCol)
        {
            //create table with verified attributes only
            //give the columns their original names (i.e., without "ref") and use that table for easier search
            Console.WriteLine(tblName);
            Console.WriteLine(attrs[0]);
            database = db;
            DataTable data = new DataTable();
            DB2DataAdapter ad = new DB2DataAdapter("select * from " + tblName+"_active;", db);
            ad.Fill(data);
            int soughtLength = data.Columns[soughtErr].MaxLength;
            DataTable matchTable = db.GetSchema(DB2MetaDataCollectionNames.Columns, new String[] { null, null, matchTbl, null });
            /*System.Collections.IEnumerator matchEn = matchTable.Columns.GetEnumerator();            
            while (matchEn.MoveNext())
                if (((DataColumn)matchEn.Current).ColumnName == soughtAttr)
                {
                    soughtLength = ((DataColumn)matchEn.Current).MaxLength;
                    break;
                }*/
            String soughtCol = matchTable.Columns[refCol].ColumnName;
            DB2Command isoErrs = new DB2Command("create table " + tblName + "_error" + whoseErrs[soughtErr].ToString()[0]+"(");
            isoErrs.CommandText += soughtAttr + " varchar(" + soughtLength + ") ";
            DataTable cols = db.GetSchema(DB2MetaDataCollectionNames.Columns, new String[] { null, null, tblName + "_active", null });
            for (int i = 0; i < attrs.Length; i++)
            {
                isoErrs.CommandText += ", " + cols.Rows[i]["column_name"].ToString()+" "+cols.Rows[i]["data_type_name"].ToString();
                if (cols.Rows[i]["data_type_name"].ToString()=="VARCHAR")
                    isoErrs.CommandText += "(" + cols.Rows[i]["column_size"].ToString() + ")"; 
            }
            isoErrs.CommandText += ", " + matchTable.Rows[refCol]["column_name"].ToString() + " " + matchTable.Rows[refCol]["data_type_name"].ToString();
            if (matchTable.Rows[refCol]["data_type_name"].ToString() == "VARCHAR")
                isoErrs.CommandText += "(" + matchTable.Rows[refCol]["column_size"] + ")";
            isoErrs.CommandText += ");";
            try
            {
                isoErrs.ExecuteNonQuery();
                Console.WriteLine(isoErrs.CommandText);
            }
            catch (InvalidOperationException ioe1)
            {
                Console.WriteLine(isoErrs.CommandText);
                Console.WriteLine(ioe1.Message);
            }
            catch (DB2Exception db2e1)
            {
                Console.WriteLine(isoErrs.CommandText);
                Console.WriteLine(db2e1.Message);
            }
            
            System.Collections.IEnumerator colEn=cols.Rows.GetEnumerator();

            isoErrs.CommandText = "insert into " + tblName + "_error" + soughtErr + " (select ";
            isoErrs.CommandText += soughtErr + ", ";
            for (int i = 0; i < attrs.Count(); i++)
                isoErrs.CommandText += tblName+"_active."+attrs[i] + ", ";
            isoErrs.CommandText += matchTable + "." + matchTable.Rows[refCol]["column_name"];
            isoErrs.CommandText += " from ";
            isoErrs.CommandText += tblName + "_active, "+matchTbl+" where " + soughtAttr + "=null);";
            try
            {
                isoErrs.ExecuteNonQuery();
                Console.WriteLine(isoErrs.CommandText);
            }
            catch (InvalidOperationException ioe1)
            {
                Console.WriteLine(ioe1.Message);
            }
            catch (DB2Exception db2e1)
            {
                Console.WriteLine(db2e1.Message);
            }
            isoErrs.CommandText = "update " + tblName + "_error" + soughtErr + " add " + matchTable.Rows[refCol]["column_name"].ToString() + " " + matchTable.Rows[refCol]["data_type_name"].ToString();
            
            TableManipulations tm = new TableManipulations(db);
            tm.CopyTables(tblName, tblName + "_clean");
            DB2Command otherClean = new DB2Command("create table " + tblName + "_no_error" + soughtErr,db);
            foreach (String s in attrs)
            {
                if (s!=soughtAttr)
                    otherClean.CommandText += "not "+s + "_ref=.null and ";
            }
            otherClean.CommandText = otherClean.CommandText.Substring(0, otherClean.CommandText.Length - 3) + ";";
            try
            {
                otherClean.ExecuteNonQuery();
                Console.WriteLine(otherClean.CommandText);
            }
            catch (InvalidOperationException ioe1)
            {
                Console.WriteLine(otherClean.CommandText);
                Console.WriteLine(ioe1.Message);
            }
            catch (DB2Exception db2e1)
            {
                Console.WriteLine(otherClean.CommandText);
                Console.WriteLine(db2e1.Message);
            }
            DataTable badRows = new DataTable();
            DB2DataAdapter badAd = new DB2DataAdapter("select * from " + tblName + "_error" + soughtErr + ";", db);
            badAd.Fill(badRows);
            /*foreach (DataRow dr in badRows.Rows) {
                for (int i=0; i<attrs.Count(); i++)
                    if(dr[attrs[i]].ToString()!="")
                        currAttrs.Add(dr[attrs[i]]);}*/
            ArrayList currAttrs = new ArrayList();
            System.Collections.IEnumerator otherAttrs = currAttrs.GetEnumerator();
            isoErrs.CommandText="update "+tblName+"_error"+soughtErr+" add ";
            while (otherAttrs.MoveNext())
            {
                isoErrs.CommandText += otherAttrs.Current.ToString() + "_primary_top num, " + otherAttrs.Current.ToString() + "_primary_bottom num, " + otherAttrs.Current.ToString() + "_secondary_top num, " + otherAttrs.Current.ToString() + "_secondary_bottom num, ";
            }
            isoErrs.CommandText = isoErrs.CommandText.Substring(0, isoErrs.CommandText.Length - 2)+";";
            try
            {
                isoErrs.ExecuteNonQuery();
                Console.WriteLine(isoErrs.CommandText);
            }
            catch (InvalidOperationException ioe1)
            {
                Console.WriteLine(ioe1.Message);
            }
            catch (DB2Exception db2e1)
            {
                Console.WriteLine(db2e1.Message);
            }
            DB2Command genRules = new DB2Command("", db);
            otherAttrs = currAttrs.GetEnumerator();
            while (otherAttrs.MoveNext())
                genRules.CommandText += " and not " + otherAttrs.Current + "_ref=null";
            otherAttrs = currAttrs.GetEnumerator();
            while (otherAttrs.MoveNext())
            {
                genRules.CommandText = "update " + tblName + "_error" + soughtErr + " set " + otherAttrs.Current.ToString() + "_primary_top=(select count(*) from " + tblName + "_active where " + tblName + "_active." + soughtAttr + "_ref=" + tblName + "_error" + soughtErr + "." + soughtAttr + "_ref and "+ "_active." + otherAttrs.Current.ToString() + "_ref=" + tblName + "_error" + soughtErr + "." + otherAttrs.Current.ToString() + "_ref" + genRules.CommandText;
                try
                {
                    genRules.ExecuteNonQuery();
                    Console.WriteLine(genRules.CommandText);
                }
                catch (InvalidOperationException ioe1)
                {
                    Console.WriteLine(ioe1.Message);
                }
                catch (DB2Exception db2e1)
                {
                    Console.WriteLine(db2e1.Message);
                }
            }
            DB2Command genAuxRules = new DB2Command("",db);
            
            otherAttrs = currAttrs.GetEnumerator();
            while (otherAttrs.MoveNext())
                genAuxRules.CommandText += " and not " + otherAttrs.Current + "_ref=.null";
            otherAttrs = currAttrs.GetEnumerator();
            while (otherAttrs.MoveNext())
            {
                System.Collections.IEnumerator otherAttrs2 = currAttrs.GetEnumerator();
                ArrayList tempLst = new ArrayList();
                while (otherAttrs2.MoveNext())
                    if (otherAttrs2.Current != otherAttrs.Current)
                        tempLst.Add(otherAttrs2.Current);
                string equalities = tblName+"_error"+soughtErr+"."+soughtAttr+tblName+"_active."+soughtAttr+" or ";
                foreach (String s in tempLst)
                    equalities += " and " + tblName + "_active." + s + "_ref=" + tblName + "_error" + soughtErr + "." + s + "_ref";
                equalities = equalities.Substring(4);
                genAuxRules.CommandText = "update " + tblName + "_error" + soughtErr + " set " + otherAttrs.Current.ToString() + "_secondary_top=(select count(*) from " + tblName + "_active where " + tblName + "_active." + otherAttrs.Current.ToString() + "_ref=" + tblName + "_error" + soughtErr + "." + otherAttrs.Current.ToString() + "_ref" +equalities+ genAuxRules.CommandText;
                try
                {
                    genAuxRules.ExecuteNonQuery();
                    Console.WriteLine(genAuxRules.CommandText);
                }
                catch (InvalidOperationException ioe1)
                {
                    Console.WriteLine(ioe1.Message);
                }
                catch (DB2Exception db2e1)
                {
                    Console.WriteLine(db2e1.Message);
                }
                genAuxRules.CommandText = "update " + tblName + "_error" + soughtErr + " set " + otherAttrs.Current.ToString() + "_secondary_bottom=(select count(*) from " + tblName + "_active where " +  equalities.Substring(4) + genAuxRules.CommandText;
                try
                {
                    genAuxRules.ExecuteNonQuery();
                    Console.WriteLine(genAuxRules.CommandText);
                }
                catch (InvalidOperationException ioe1)
                {
                    Console.WriteLine(ioe1.Message);
                }
                catch (DB2Exception db2e1)
                {
                    Console.WriteLine(db2e1.Message);
                }
            }
            colEn = cols.Rows.GetEnumerator();
        }
    }
}

