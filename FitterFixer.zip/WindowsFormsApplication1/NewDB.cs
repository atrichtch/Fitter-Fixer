﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
/*@author Alex Trichtchenko
 * Not for commercial use
 */

using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using IBM.Data.DB2;
using IBM.Data.DB2Types;
using System.Runtime.InteropServices;

namespace WindowsFormsApplication1
{
    public partial class NewDB : Form
    {
        public NewDB()
        {
            InitializeComponent();
        }
        [DllImport(/*"C:\\Users\\alex\\Documents\\Visual Studio 2008\\Projects\\DBOperations\\Debug\\DBOperations.dll"*/"DBOperations.dll")]
        public static extern void blank_database(IntPtr pDbName);

        [DllImport("C:\\Users\\alex\\Documents\\Visual Studio 2008\\Projects\\DBOperations\\Debug\\DBOperations.dll")]
        public static extern int num_Dbs();

        private void button1_Click(object sender, EventArgs e)
        {
            Thread makeTh=new Thread(makeDb);
            makeTh.Start();
        }

        private void makeDb()
        {
            IntPtr ptr = Marshal.StringToHGlobalAnsi(textBox1.Text);
            //Marshal.StructureToPtr(dbName, ptr, true);
            try
            {
                blank_database(ptr);
            }
            catch (DllNotFoundException dlle)
            {
                Console.WriteLine(dlle.Message);
            }
            catch (EntryPointNotFoundException epnfe)
            {
                Console.WriteLine(epnfe.Message);
            }
        }

        private void checkProgress()
        {
            //check if the newly created database exists
        }
    }
}
