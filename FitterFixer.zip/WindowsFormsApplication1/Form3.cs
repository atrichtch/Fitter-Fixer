﻿/*@author Alex Trichtchenko
 * Not for commercial use
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Reflection;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;
using System.Windows.Forms;
using IBM.Data.DB2;
using IBM.Data.DB2Types;
using System.Runtime.InteropServices;

namespace WindowsFormsApplication1
{
    public partial class Form3 : Form
    {
        private String dataCSV;
        private String dataset;
        private DB2Connection localEstab;
        public Form3()
        {
            InitializeComponent();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked)
            {
                comboBox2.Enabled = false;
                //label3.Enabled = false;
            }
            else
            {
                comboBox2.Enabled = true;
                //label3.Enabled = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

                FolderBrowserDialog fd = new FolderBrowserDialog();
                if (fd.ShowDialog() == DialogResult.OK)
                {
                    if (fd.SelectedPath != "")
                    {
                        DirectoryInfo curDir = new DirectoryInfo(fd.SelectedPath + "\\DB2\\NODE0000");
                        if (curDir.Exists)
                        {
                            DirectoryInfo[] f = curDir.GetDirectories();
                            textBox1.Text = fd.SelectedPath;
                            for (int i = 0; i < f.Length; i++)
                            {
                                if (!f[i].Name.StartsWith("SQL"))
                                    comboBox1.Items.Add(f[i].Name);
                            }
                        }
                    }
                }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                textBox2.Enabled = true;
                groupBox3.Enabled = true;
            }
            else {
                textBox2.Enabled = true;
                groupBox3.Enabled = true;
            }
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (radioButton2.Checked)
            {
                try
                {
                    localEstab.Open();
                    //FileDialog fd = new OpenFileDialog();
                    //fd.Filter = "Comma Separated Values|*.csv";
                    //if (fd.ShowDialog() == DialogResult.OK)
                    //{
                    //    textBox2.Text = fd.FileName;
                        CSVParser parser = new CSVParser();
                        parser.parse(textBox2.Text, localEstab);
                    //}
                }
                catch (DB2Exception db2e)
                {
                    Console.WriteLine(db2e.Message);
                }
            }
            if (radioButton4.Checked)
            {
                String dbName = textBox1.Text;
                Regex badExp = new Regex("[^a-zA-Z0-9]");
                if (badExp.IsMatch(dbName) || dbName.Length > 8)
                {
                    textBox1.BackColor = Color.Red;
                    return;
                }
                //Console.WriteLine(Directory.GetParent(Directory.GetParent(Directory.GetCurrentDirectory()).FullName).FullName);
                IntPtr ptr = Marshal.StringToHGlobalAnsi(dbName);
                //Marshal.StructureToPtr(dbName, ptr, true);
                try
                {
                    blank_database(ptr);
                }
                catch (DllNotFoundException dlle)
                {
                    Console.WriteLine(dlle.Message);
                }
                catch (EntryPointNotFoundException epnfe)
                {
                    Console.WriteLine(epnfe.Message);
                }
                localEstab = new DB2Connection("Database=" + dbName);
                try
                {
                    localEstab.Open();
                    //FileDialog fd = new OpenFileDialog();
                    //fd.Filter = "Comma Separated Values|*.csv";
                    //if (fd.ShowDialog() == DialogResult.OK)
                    {
                        CSVParser parser = new CSVParser();
                        Console.WriteLine("Now switching to parsing.");
                        parser.parse(dataCSV, localEstab);
                    }
                }
                catch (DB2Exception db2e)
                {
                    Console.WriteLine(db2e.Message);
                }
            }
            if (!localEstab.IsOpen)
                localEstab.Open();
            Form4 f4 = new Form4(localEstab, dataset);
            //backup in case something goes wrong
            this.Visible = false;
            if (f4.ShowDialog() == DialogResult.Cancel)
                this.Visible = true;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            localEstab = new DB2Connection("Database="+comboBox1.SelectedItem.ToString());
            try
            {
                if (radioButton1.Checked)
                {
                    comboBox2.Items.Clear();
                    localEstab.Open();
                    DataTable dt = localEstab.GetSchema(DB2MetaDataCollectionNames.Tables);
                    foreach (DataRow dr in dt.Rows)
                    {
                        //Console.WriteLine(dr["table_name"]);
                        if (!dr["table_schema"].ToString().StartsWith("SYS"))
                            comboBox2.Items.Add(dr["table_name"]);
                    }
                    //localEstab.Close();
                }
            }
            catch (DB2Exception ep) {
                Console.WriteLine(ep.Message);
            }
            
        }


        [DllImport(/*"C:\\Users\\alex\\Documents\\Visual Studio 2008\\Projects\\DBOperations\\Debug\\DBOperations.dll"*/"DBOperations.dll")]
        public static extern void blank_database(IntPtr pDbName);

        private void button4_Click(object sender, EventArgs e)
        {
            if (radioButton2.Checked)
            {    
                try
                {
                    if (!localEstab.IsOpen)
                        localEstab.Open();
                    FileDialog fd = new OpenFileDialog();
                    fd.Filter = "Comma Separated Values|*.csv";
                    if (fd.ShowDialog() == DialogResult.OK)
                    {
                        textBox2.Text = fd.FileName;
                        CSVParser parser = new CSVParser();
                        parser.parse(fd.FileName, localEstab);
                        dataset = fd.FileName.Split('\\').Last().Substring(0,fd.FileName.Split('\\').Last().Length-3);
                    }
                }
                catch (DB2Exception db2e)
                {
                    Console.WriteLine(db2e.Message);
                }
            }
            if (radioButton4.Checked)
            {
                FileDialog fd = new OpenFileDialog();
                fd.Filter = "Comma Separated Values|*.csv";
                while (!fd.FileName.EndsWith(".csv"))
                {
                    if (fd.ShowDialog() == DialogResult.OK)
                    {
                        dataCSV = fd.FileName;
                        textBox2.Text = fd.FileName;
                        dataset = dataCSV.Split('\\').Last().Substring(0, dataCSV.Split('\\').Last().Length - 4);
                    }
                }
                /*String dbName = textBox1.Text;
                //Console.WriteLine(Directory.GetParent(Directory.GetParent(Directory.GetCurrentDirectory()).FullName).FullName);
                IntPtr ptr = Marshal.StringToHGlobalAnsi(dbName);
                //Marshal.StructureToPtr(dbName, ptr, true);
                try
                {
                    blank_database(ptr);
                }
                catch (DllNotFoundException dlle)
                {
                    Console.WriteLine(dlle.Message);
                }
                catch (EntryPointNotFoundException epnfe)
                {
                    Console.WriteLine(epnfe.Message);
                }
                localEstab=new DB2Connection("Database="+dbName);
                try
                {
                    localEstab.Open();
                    FileDialog fd = new OpenFileDialog();
                    fd.Filter = "Comma Separated Values|*.csv";
                    if (fd.ShowDialog() == DialogResult.OK)
                    {
                        CSVParser parser = new CSVParser();
                        parser.parse(fd.FileName, localEstab);
                    }
                }
                catch (DB2Exception db2e)
                {
                    Console.WriteLine(db2e.Message);
                }*/
            }
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton4.Checked)
            {
                groupBox2.Text = "Database";
                comboBox1.Enabled = false;
                button1.Enabled = false;
                label2.Enabled = false;
                comboBox2.Enabled = false;
                label1.Text = "";
                //label3.Enabled = false;
            }
            else
            {
                groupBox2.Text = "Database path";
                comboBox1.Enabled = true;
                button1.Enabled = true;
                label2.Enabled = true;
                comboBox2.Enabled = true;
                label1.Text = "Path";
                //label3.Enabled = true;
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            dataset = comboBox2.SelectedItem.ToString();
        }

    }
}
