﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Collections;
using System.Windows.Forms;
using IBM.Data.DB2;
using IBM.Data.DB2Types;

namespace FitterFixer
{
    public partial class DupliForm : Form
    {
        private ArrayList identifiers;
        private ArrayList otherAttrs;
        private DB2Connection db;
        private String dataset;
        public DupliForm()
        {
            InitializeComponent();
        }

        public DupliForm(DB2Connection db, String dataset)
        {
            this.db=db;
            this.dataset=dataset;
            InitializeComponent();
            DataTable columns=db.GetSchema(DB2MetaDataCollectionNames.Columns, new String[] { null, null, dataset, null });
            foreach (DataRow dr in columns.Rows)
            {
                listBox2.Items.Add(dr.ToString());
                otherAttrs.Add(dr.ToString());
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (listBox2.SelectedItem != null)
            {
                String[] curInfo = new String[3];
                curInfo[0] = listBox1.SelectedItem.ToString();
                this.identifiers.Add(listBox2.SelectedItem.ToString());
                this.otherAttrs.Remove(listBox2.SelectedIndex);
                listBox1.Items.Add(listBox2.SelectedItem);
                //comboBox2.Items.Add(listBox1.SelectedItem);
                listBox2.Items.Remove(listBox2.SelectedItem);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem != null)
            {
                String[] curInfo = new String[3];
                curInfo[0] = listBox1.SelectedItem.ToString();
                listBox2.Items.Add(listBox1.SelectedItem);
                //comboBox2.Items.Add(listBox1.SelectedItem);
                listBox1.Items.Remove(listBox1.SelectedItem);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DB2Command dupSet = new DB2Command("create table " + dataset + "_tmp like "+dataset+";",db);
            try
            {
                dupSet.ExecuteNonQuery();
            }
            catch (InvalidOperationException f)
            {
                Console.WriteLine(f.Message);
            }
            catch (DB2Exception d)
            {
                Console.WriteLine(d.Message);
            }
            dupSet.CommandText = "alter table " + dataset + "_tmp add primary key(";
            for (int i = 0; i < identifiers.Count; i++)
                dupSet.CommandText += identifiers[i] + ", ";
            dupSet.CommandText = dupSet.CommandText.Substring(0, dupSet.CommandText.Length - 2);
            dupSet.CommandText += ");";
            try
            {
                dupSet.ExecuteNonQuery();
            }
            catch (InvalidOperationException f)
            {
                Console.WriteLine(f.Message);
            }
            catch (DB2Exception d)
            {
                Console.WriteLine(d.Message);
            }
            dupSet.CommandText = "alter table " + dataset + "_tmp drop";

            for (int i = 0; i < otherAttrs.Count; i++)
                dupSet.CommandText += otherAttrs[i] + ", ";
            dupSet.CommandText = dupSet.CommandText.Substring(0, dupSet.CommandText.Length - 2);
            dupSet.CommandText += ");";
            try
            {
                dupSet.ExecuteNonQuery();
            }
            catch (InvalidOperationException f)
            {
                Console.WriteLine(f.Message);
            }
            catch (DB2Exception d)
            {
                Console.WriteLine(d.Message);
            }
            
            dupSet.CommandText = "insert into " + dataset + "_tmp (select distinct";
            for (int i = 0; i < identifiers.Count; i++)
                dupSet.CommandText += identifiers[i] + ", ";
            dupSet.CommandText = dupSet.CommandText.Substring(0, dupSet.CommandText.Length - 2);
            dupSet.CommandText += "from "+dataset+");";
            try
            {
                dupSet.ExecuteNonQuery();
            }
            catch (InvalidOperationException f)
            {
                Console.WriteLine(f.Message);
            }
            catch (DB2Exception d)
            {
                Console.WriteLine(d.Message);
            }
            dupSet.CommandText = "alter table " + dataset + "_tmp add freq num";
            try
            {
                dupSet.ExecuteNonQuery();
            }
            catch (InvalidOperationException f)
            {
                Console.WriteLine(f.Message);
            }
            catch (DB2Exception d)
            {
                Console.WriteLine(d.Message);
            }
            String sqlChar = "update "+dataset+"_tmp set freq=(select count (distinct ";
            for (int i = 0; i < otherAttrs.Count; i++)
                sqlChar += otherAttrs[i]+", ";
            sqlChar = sqlChar.Substring(0, sqlChar.Length - 2);
            sqlChar += ") from "+ dataset+" group by ";
            for (int i = 0; i < identifiers.Count; i++)
                sqlChar += identifiers[i] + ", ";
            sqlChar = sqlChar.Substring(0, sqlChar.Length - 2);
            sqlChar += ");";
            DB2Command extDup=new DB2Command(sqlChar,db);
            try
            {
                extDup.ExecuteNonQuery();
            }
            catch (InvalidOperationException f)
            {
                Console.WriteLine(f.Message);
            }
            catch (DB2Exception d)
            {
                Console.WriteLine(d.Message);
            }
            dupSet.CommandText = "create table " + dataset + "_filter like " + dataset + "_tmp;";
            dupSet.CommandText = "alter table " + dataset + "_filter add record_no num;";
            dupSet.CommandText = "alter table " + dataset + "_filter add primary key (record_no)";
            dupSet.CommandText = "insert into " + dataset + "_filter (select ";
            for (int i = 0; i < identifiers.Count; i++)
                dupSet.CommandText += dataset+"_tmp."+identifiers[i] + ", ";
            dupSet.CommandText += "row_number() over() from " + dataset + "_tmp);";
            try
            {
                extDup.ExecuteNonQuery();
            }
            catch (InvalidOperationException f)
            {
                Console.WriteLine(f.Message);
            }
            catch (DB2Exception d)
            {
                Console.WriteLine(d.Message);
            }
            dupSet.CommandText = "drop table " + dataset + "_tmp;";
            try
            {
                extDup.ExecuteNonQuery();
            }
            catch (InvalidOperationException f)
            {
                Console.WriteLine(f.Message);
            }
            catch (DB2Exception d)
            {
                Console.WriteLine(d.Message);
            }
            dupSet.CommandText = "create table " + dataset + "_no_dup like " + dataset + ";";
            try
            {
                extDup.ExecuteNonQuery();
            }
            catch (InvalidOperationException f)
            {
                Console.WriteLine(f.Message);
            }
            catch (DB2Exception d)
            {
                Console.WriteLine(d.Message);
            }
            dupSet.CommandText = "alter table " + dataset + "_no_dup add record_no num;";
            try
            {
                extDup.ExecuteNonQuery();
            }
            catch (InvalidOperationException f)
            {
                Console.WriteLine(f.Message);
            }
            catch (DB2Exception d)
            {
                Console.WriteLine(d.Message);
            }
            dupSet.CommandText = "alter table " + dataset + "_no_dup add foreign key (record_no) references " + dataset + "_filter;";
            try
            {
                extDup.ExecuteNonQuery();
            }
            catch (InvalidOperationException f)
            {
                Console.WriteLine(f.Message);
            }
            catch (DB2Exception d)
            {
                Console.WriteLine(d.Message);
            }
            dupSet.CommandText = "insert into " + dataset + "_no_dup select ";
            for (int i = 0; i < identifiers.Count; i++)
                dupSet.CommandText += dataset + "." + identifiers[i] + ", ";
            for (int i = 0; i < otherAttrs.Count; i++)
                dupSet.CommandText += dataset + "." + otherAttrs[i] + ", ";
            dupSet.CommandText+=dataset+"_filter.record_no from "+dataset+", "+dataset+"_filter where ";
            for (int i = 0; i < identifiers.Count; i++)
                dupSet.CommandText += dataset + "_filter." + identifiers[i] + " = "+dataset+"."+identifiers[i]+" and ";
            dupSet.CommandText += dataset+"_filter.freq=1);";
            try
            {
                extDup.ExecuteNonQuery();
            }
            catch (InvalidOperationException f)
            {
                Console.WriteLine(f.Message);
            }
            catch (DB2Exception d)
            {
                Console.WriteLine(d.Message);
            }
            dupSet.CommandText = "create table " + dataset + "_dup like " + dataset + ";";
            try
            {
                extDup.ExecuteNonQuery();
            }
            catch (InvalidOperationException f)
            {
                Console.WriteLine(f.Message);
            }
            catch (DB2Exception d)
            {
                Console.WriteLine(d.Message);
            }
            for (int i = 0; i < identifiers.Count; i++)
            {
                dupSet.CommandText = "alter table " + dataset + "_dup drop " + identifiers[i] + ";";
                try
                {
                    extDup.ExecuteNonQuery();
                }
                catch (InvalidOperationException f)
                {
                    Console.WriteLine(f.Message);
                }
                catch (DB2Exception d)
                {
                    Console.WriteLine(d.Message);
                }
            }
            dupSet.CommandText = "alter table " + dataset + "_dup add record_no num not null foreign key references " + dataset + "_filter;";
            try
            {
                extDup.ExecuteNonQuery();
            }
            catch (InvalidOperationException f)
            {
                Console.WriteLine(f.Message);
            }
            catch (DB2Exception d)
            {
                Console.WriteLine(d.Message);
            }
            dupSet.CommandText = "insert into " + dataset + "_dup select ";
            for (int i = 0; i < otherAttrs.Count; i++)
                dupSet.CommandText += otherAttrs[i] + ", ";
            dupSet.CommandText += dataset + "_filter.record_no from " + dataset + ", " + dataset + "_filter where ";
            for (int i = 0; i < identifiers.Count; i++)
                dupSet.CommandText += dataset + "_filter." + identifiers[i] + " = " + dataset + "." + identifiers[i] + " and ";
            dupSet.CommandText += dataset + "_filter.freq>1);";
            try
            {
                extDup.ExecuteNonQuery();
            }
            catch (InvalidOperationException f)
            {
                Console.WriteLine(f.Message);
            }
            catch (DB2Exception d)
            {
                Console.WriteLine(d.Message);
            }
            DataTable dups = new DataTable();
            DB2DataAdapter dupada = new DB2DataAdapter("select * from " + dataset + "_dup;", db);
            try
            {
                dupada.Fill(dups);
            }
            catch (InvalidOperationException f)
            {
                Console.WriteLine(f.Message);
            }
            catch (DB2Exception d)
            {
                Console.WriteLine(d.Message);
            }
            dataGridView1.DataSource = dups;
            DataTable noDups = new DataTable();
            DB2DataAdapter noDupada = new DB2DataAdapter("select * from " + dataset + "_no_dup;", db);
            try
            {
                noDupada.Fill(noDups);
            }
            catch (InvalidOperationException f)
            {
                Console.WriteLine(f.Message);
            }
            catch (DB2Exception d)
            {
                Console.WriteLine(d.Message);
            }
            dataGridView2.DataSource = noDups;
        }
    }
}
