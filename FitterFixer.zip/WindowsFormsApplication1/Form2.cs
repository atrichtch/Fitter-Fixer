﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IBM.Data.DB2;

namespace WindowsFormsApplication1
{
    public partial class Form2 : Form
    {
        DB2Connection myConn;
        int errNum;
        String sqlString;
        Form1 f1;
        public Form2(DB2Connection conn)
        {
            errNum = 0;
            dataSet1.Tables.Add(new DataTable(conn.Database));
            InitializeComponent();
            f1 = new Form1();
        //    f1.Show();
            if (f1.ShowDialog()==DialogResult.OK)
            {
                MessageBox.Show("hello");
                try
                {
                    StreamReader sr = new StreamReader(f1.getFile());
                    try
                    {
                        String s = sr.ReadLine();
                        String[] attrs = s.Split(',');
                        for (int i = 0; i<attrs.Length; i++)
                        {
                            MessageBox.Show(i.ToString());
    //                        comboBox1.Items.Add(attrs[i]);
                        }
                    }
                    catch (Exception e)
                    {
                        MessageBox.Show(e.Message);
                    }
                }
                catch (ArgumentException e) { }
            }
            else MessageBox.Show("no");
        }
  /*      private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            sqlString = "create table error" + errNum + " as select " + comboBox1.SelectedText + " from " + f1.getDB().Database;
        }
        */
        private void button1_Click(object sender, EventArgs e)
        {
            DB2Command c1 = new DB2Command(sqlString, f1.getDB());
            this.Close();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}
