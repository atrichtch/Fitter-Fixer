﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using IBM.Data.DB2;
using IBM.Data.DB2Types;

namespace WindowsFormsApplication1
{
    public partial class Form6 : Form
    {
        private DB2Connection localEstab;
        private String tblName;
        //private String[] cols;
        int nErrs;
        public Form6(DB2Connection c, String s, int n)
        {
            localEstab = c;
            tblName = s;
            nErrs = n;
        }

        public Form6(DB2Connection c, String s, String[] cols, int n)
        {
            localEstab = c;
            tblName = s;
            nErrs = n;
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form6_Load(object sender, EventArgs e)
        {
            DataTable dt = localEstab.GetSchema(DB2MetaDataCollectionNames.Columns);
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            FileDialog fd = new OpenFileDialog();
            if (fd.ShowDialog() == DialogResult.OK)
            {

                StreamReader reader = new StreamReader(fd.FileName, new UTF7Encoding());
                try
                {
                    String curLn = reader.ReadLine();
                    //int nChars;
                    //int[] splitInds;
                    String tblName2 = fd.FileName;
                    //bool quotesMatched;
                    Console.WriteLine(curLn);
                    String[] attribs = curLn.Split(',');
                    String[] finalAttrs = new String[attribs.Length];
                    int soFar = 0;
                    for (int i = 0; i < attribs.Length; i++)
                    {
                        finalAttrs[soFar] = attribs[i];
                        Console.WriteLine(attribs[i]);
                        if (attribs[i].StartsWith("\""))
                        {
                            while (!attribs[i].EndsWith("\"") && i < attribs.Length)
                            {
                                i++;
                                finalAttrs[soFar] = finalAttrs[soFar] + attribs[i];
                            }
                        }
                        soFar++;
                        Console.WriteLine(soFar);
                    }
                    String[,] data = new String[100, soFar];
                    Console.WriteLine(data.Length);
                    int nLns = 1;
                    string[] vtypes = new string[soFar];
                    bool[] nums = new bool[soFar];
                    bool[] dates = new bool[soFar];
                    bool[] texts = new bool[soFar];

                    for (int i = 0; i < soFar; i++)
                    {
                        vtypes[i] = "";
                        Console.WriteLine(i);
                        nums[i] = true;
                    }
                    curLn = reader.ReadLine();
                    int[] maxLgt = new int[soFar];
                    for (int i = 0; i < soFar; i++)
                        maxLgt[i] = 0;
                    while (curLn != null)
                    {
                        //chExps = new String[attrs.Length];
                        //nChars = 0;
                        if (nLns == 10)
                            Console.WriteLine(curLn);
                        //Console.WriteLine(curLn);
                        //quotesMatched = true;
                        String[] entries = curLn.Split(',');
                        if (nLns == data.Length / soFar + 1)
                        {
                            String[,] temp = new String[data.Length / soFar, soFar];
                            for (int i = 0; i < data.Length / soFar; i++)
                                for (int j = 0; j < soFar; j++)
                                    temp[i, j] = data[i, j];
                            data = new String[2 * data.Length / soFar, soFar];
                            for (int i = 0; i < temp.Length / soFar; i++)
                                for (int j = 0; j < soFar; j++)
                                    data[i, j] = temp[i, j];
                        }
                        String[] finalEntries = new String[finalAttrs.Length];
                        int nEntr = 0;
                        for (int i = 0; i < entries.Length; i++)
                        {
                            finalEntries[nEntr] = entries[i];
                            if (entries[i].StartsWith("\""))
                            {
                                finalEntries[nEntr] = finalEntries[nEntr].Substring(1);
                                while (!entries[i].EndsWith("\"") && i < entries.Length)
                                {
                                    i++;
                                    finalEntries[nEntr] = finalEntries[nEntr] + "," + entries[i];
                                }
                                finalEntries[nEntr] = finalEntries[nEntr].Substring(0, finalEntries[nEntr].Length - 1);
                            }
                            nEntr++;
                        }
                        if (nEntr != soFar)
                        {
                            Console.WriteLine("Parsing error");
                            break;
                        }
                        for (int i = 0; i < soFar; i++)
                        {
                            data[nLns - 1, i] = finalEntries[i];
                            if (finalEntries[i].Length > maxLgt[i])
                                maxLgt[i] = finalEntries[i].Length;
                        }
                        for (int i = 0; i < soFar; i++)
                        {
                            if (nums[i])
                            {
                                String[] mantFrac = finalEntries[i].Split('.');
                                if (mantFrac.Length > 2) nums[i] = false;
                                for (int j = 0; j < mantFrac.Length && nums[i]; j++)
                                {
                                    for (int k = 0; k < mantFrac[j].Length && nums[i]; k++)
                                    {
                                        if (mantFrac[j].ToCharArray()[k] >= '0' && mantFrac[j].ToCharArray()[k] <= '9')
                                            nums[i] = true;
                                        else
                                        {
                                            nums[i] = false;
                                            dates[i] = true;
                                            if (i >= 12)
                                            {
                                                Console.WriteLine(finalEntries[i]);
                                                Console.Write(finalAttrs[i]);
                                                Console.Write(" now false\n");
                                            }
                                        }
                                    }
                                }
                            }
                            else if (dates[i])
                            {
                                try
                                {
                                    System.DateTime dt = System.DateTime.Parse(finalEntries[i]);

                                }
                                catch
                                {
                                    dates[i] = false;
                                    texts[i] = true;
                                }
                            }
                        }

                        
                        nLns++;
                        curLn = reader.ReadLine();
                    }
                    for (int i = 0; i < soFar; i++)
                        maxLgt[i] += 5;
                    for (int i = 0; i < soFar; i++)
                        if (nums[i]) vtypes[i] = "num";
                        else if (dates[i]) vtypes[i] = "date";
                        else vtypes[i] = "char";
                    for (int i = 0; i < nLns - 1; i++)
                        for (int j = 0; j < soFar; j++)
                            if (vtypes[j] == "num" || vtypes[j] == "date")
                                if (data[i, j] == "")
                                    data[i, j] = "null";
                    String shrtTblName = tblName2.Split('\\').Last();
                    shrtTblName = shrtTblName.Substring(0, shrtTblName.Length - 4);
                    String sqlString = "create table " + shrtTblName;
                    if (vtypes[0] == "char")
                        sqlString += " (" + finalAttrs[0] + " " + "varchar" + "(" + maxLgt[0].ToString() + ")";
                    else
                        sqlString += " (" + finalAttrs[0] + " " + vtypes[0];
                    for (int i = 1; i < soFar; i++)
                        if (vtypes[i] == "char")
                            sqlString = sqlString + ", " + finalAttrs[i] + " " + "varchar(" + maxLgt[i] + ")";
                        else
                            sqlString = sqlString + ", " + finalAttrs[i] + " " + vtypes[i];
                    sqlString = sqlString + ");";
                    Console.WriteLine(sqlString);
                    localEstab = new DB2Connection("Database=Sample");
                    DB2Command db2c = new DB2Command(sqlString, localEstab);
                    try
                    {
                        localEstab.Open();
                        Console.WriteLine("Connection done");
                        try
                        {
                            db2c.ExecuteNonQuery();
                        }
                        catch (InvalidOperationException ex) {
                            Console.WriteLine(ex.Message);
                        }
                        for (int i = 0; i < nLns - 1; i++)
                        {
                            String sqlString2 = "insert into " + shrtTblName + " values (";
                            if (vtypes[0].Equals("char"))
                            {
                                if (sqlString2.Contains('\''))
                                {
                                    String[] temp = data[i, 0].Split('\'');
                                    sqlString2 += "'" + temp[0];
                                    for (int j = 1; j < temp.Length; j++)
                                        sqlString2 += "'" + temp[j];
                                    sqlString2 += "'";
                                }
                                else
                                    sqlString2 += "'" + data[i, 0] + "'";
                            }
                            else if (vtypes[0].Equals("date"))
                                sqlString2 += "'" + System.DateTime.Parse(data[i, 0]).Year.ToString() + "-" + System.DateTime.Parse(data[i, 0]).Month.ToString() + "-" + System.DateTime.Parse(data[i, 0]).Day.ToString() + "'";
                            else
                                sqlString2 += data[i, 0];
                            for (int j = 1; j < soFar; j++)
                            {
                                if (vtypes[j] == "char")
                                {
                                    try
                                    {
                                        if (data[i, j].Contains('\''))
                                        {
                                            String[] temp = data[i, j].Split('\'');
                                            sqlString2 += ", '" + temp[0];
                                            for (int k = 1; k < temp.Length; k++)
                                                sqlString2 += "''" + temp[k];
                                            sqlString2 += "'";
                                        }
                                        else
                                            sqlString2 += ", '" + data[i, j] + "'";
                                    }
                                    catch (IndexOutOfRangeException inde)
                                    {
                                        Console.WriteLine(inde.Message);
                                        Console.WriteLine("Something wrong with the line");
                                    }
                                }
                                else if (vtypes[j] == "date")
                                    sqlString2 += ", '" + System.DateTime.Parse(data[i, j]).Year.ToString() + "-" + System.DateTime.Parse(data[i, j]).Month.ToString() + "-" + System.DateTime.Parse(data[i, j]).Day.ToString() + "'";
                                else
                                    sqlString2 += ", " + data[i, j];
                            }
                            sqlString2 += ");";
                            DB2Command localComm = new DB2Command(sqlString2, localEstab);
                            try
                            {
                                localComm.ExecuteNonQuery();
                                if (i == 0)
                                {
                                    Console.WriteLine(sqlString2);
                                    Console.WriteLine("Success");
                                }
                            }
                            catch (InvalidOperationException excpt)
                            {
                                Console.WriteLine(sqlString2);
                                Console.WriteLine("Failed");
                                Console.WriteLine(excpt.Message);
                                break;
                            }
                            catch (DB2Exception db2e)
                            {
                                Console.WriteLine(sqlString2);
                                Console.WriteLine("Failed");
                                Console.WriteLine(db2e.Message);
                                break;
                            }
                        }
                        localEstab.Close();
                    }
                    catch (DB2Exception exc) {
                        Console.WriteLine(exc.Message);
                    }
                }
                catch { }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            String shortTblName = tblName.Split('\\').Last();
            String sqlString = "alter table "+shortTblName+" add error"+nErrs+" num";
            DB2Command db2c = new DB2Command(sqlString, localEstab);
            try
            {
                localEstab.Open();
                try
                {
                    db2c.ExecuteNonQuery();
                }
                catch (InvalidOperationException ope)
                {
                    Console.WriteLine(sqlString);
                    Console.WriteLine("failed");
                    Console.WriteLine(ope.Message);
                }
            }
            catch (DB2Exception eb2e) {
                Console.WriteLine(eb2e.Message);
            }
            String sqlString2 = "update " + shortTblName + " set error" + nErrs + "=1 where " + comboBox1.SelectedItem + "='' or not exists (select ";
            for (int i = 0; i < listBox1.Items.Count; i++ )
            { }
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
