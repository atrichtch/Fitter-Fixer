﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IBM.Data.DB2;
using IBM.Data.DB2Types;
using FitterFixer;


namespace WindowsFormsApplication1
{
    public partial class Form4 : Form
    {
        DB2Connection myConn;
        String tableName;
        ArrayList attrs;
        ArrayList tables;
        ArrayList curColumns;
        int nErrs;

        ArrayList errors;
        ArrayList catErrs;
        ArrayList catMatches;
        ArrayList catRefs;

        ArrayList spErrs;
        ArrayList spMatches;
        ArrayList spRefs;
        ArrayList[] whoseErrs;
        DataTable colDefs; //columns definitions
        String[] codeDefs; //definitons of corresponding code columns
        String[] matchTbls;  //corresponding match tables
        String[] codeCols; //corresponding code columns
        //bool[] errSet; //whether or not an error has been defined
        String[] cols;
        ArrayList allColumns;
        ArrayList[] whoseRefs;
        public Form4()
        {
            InitializeComponent();
        }

        public Form4(DB2Connection dc)
        {
            myConn = dc;
            InitializeComponent();
        }

        public Form4(DB2Connection dc, String s)
        {
            myConn = dc;
            tableName = s;
            InitializeComponent();
        }

        public Form4(DB2Connection dc, String s, bool fromFile)
        {
            myConn = dc;
            tableName = s;
            if (fromFile)
                textBox1.Text = tableName;
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form4_Load(object sender, EventArgs e)
        {
            errors = new ArrayList();
            attrs = new ArrayList();
            tables = new ArrayList();
            curColumns = new ArrayList();
            textBox1.Text = tableName;
            dataGridView1.AutoGenerateColumns = true;
            String shortTblName = tableName.Split('\\').Last();
            DataTable dt = myConn.GetSchema(DB2MetaDataCollectionNames.Columns, new String[4] {null, null, shortTblName, null});
            colDefs = myConn.GetSchema(DB2MetaDataCollectionNames.Columns, new String[4] { null, null, shortTblName, null });
            matchTbls = new String[colDefs.Rows.Count];
            //errSet = new bool[colDefs.Rows.Count];
            codeCols = new String[colDefs.Rows.Count];
            cols = new String[dt.Rows.Count];
            allColumns = new ArrayList();
            catErrs = new ArrayList();
            catMatches = new ArrayList();
            catRefs = new ArrayList();

            spErrs = new ArrayList();
            spMatches = new ArrayList();
            spRefs = new ArrayList();
            codeDefs = new String[colDefs.Rows.Count];
            whoseRefs = new ArrayList[dt.Rows.Count];
            nErrs = 0;
            int i=0;
            whoseErrs = new ArrayList[cols.Length];
            foreach (DataRow dr in dt.Rows)
            {
                allColumns.Add(dr["column_name"].ToString());
                cols[i] = dr["column_name"].ToString();
                comboBox1.Items.Add(dr["column_name"]);
                attrs.Add(dr["column_name"].ToString());
                whoseErrs[i] = new ArrayList();
                whoseRefs[i] = new ArrayList();
                i++;
                //Console.WriteLine(dr["data_type_name"]+" "+dr["column_size"]);
            }
            foreach (DataColumn c in dt.Columns)
            {
                //Console.WriteLine(c.ColumnName);
            }
            DB2DataAdapter ad = new DB2DataAdapter("select * from " + shortTblName + " fetch first 10 rows only;", myConn);
            DataTable ourData = new DataTable();
            ad.Fill(ourData);
            dataGridView1.DataSource = ourData;
            dataGridView1.Refresh();
            DataTable dt2 = myConn.GetSchema(DB2MetaDataCollectionNames.Tables);
            foreach (DataRow dr in dt2.Rows)
            {
                //Console.WriteLine(dr["table_name"]);
                if (!dr["table_name"].ToString().StartsWith("SYS"))
                {
                    tables.Add(dr["table_name"].ToString());
                    comboBox3.Items.Add(dr["table_name"]);
                }
            }
            if (!myConn.IsOpen)
                myConn.Open();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem == null)
                comboBox1.BackColor = Color.Red;
            if (comboBox3.SelectedItem == null)
                comboBox3.BackColor = Color.Red;
            if (comboBox1.SelectedItem != null && comboBox3.SelectedItem != null)
            {
                nErrs++;
                String briefTblName = tableName.Split('\\').Last();
                String[] curErr = new String[3];
                //errSet[comboBox1.SelectedIndex] = true;
                DataTable toMatch = myConn.GetSchema(DB2MetaDataCollectionNames.Columns, new String[] { null, null, comboBox3.SelectedItem.ToString(), null });
                matchTbls[comboBox1.SelectedIndex] = comboBox1.SelectedItem.ToString();
                codeDefs[comboBox1.SelectedIndex] = toMatch.Rows[comboBox2.SelectedIndex]["data_type_name"].ToString();
                if (toMatch.Rows[comboBox2.SelectedIndex]["data_type_name"].ToString() == "VARCHAR" ||
                    toMatch.Rows[comboBox2.SelectedIndex]["data_type_name"].ToString() == "DECIMAL")
                    codeDefs[comboBox1.SelectedIndex] += "(" + toMatch.Rows[comboBox2.SelectedIndex]["column_size"].ToString() + ")";
                codeCols[comboBox1.SelectedIndex] = comboBox2.SelectedItem.ToString();
                curErr[0] = nErrs.ToString();
                curErr[1] = comboBox1.SelectedItem.ToString();
                if (radioButton1.Checked)
                {
                    curErr[2] = "spelling";
                    spErrs.Add(comboBox1.SelectedItem.ToString() + " " + nErrs);
                    spMatches.Add(comboBox3.SelectedItem.ToString());
                    spRefs.Add((String)curColumns[comboBox2.SelectedIndex]);
                    DB2Command comm = new DB2Command("alter table " + briefTblName + " add spell_err_" + catErrs.Count + " num;", myConn);
                    try
                    {
                        comm.ExecuteNonQuery();
                    }
                    catch (InvalidOperationException excpt)
                    {
                        Console.WriteLine(comm.CommandText);
                        Console.WriteLine(excpt.Message);
                    }
                    catch (DB2Exception db2e)
                    {
                        Console.WriteLine(comm.CommandText);
                        Console.WriteLine(db2e.Message);
                    }
                    comm.CommandText = "update " + briefTblName + " set spell_err_" + spErrs.Count + "=0 where not "
                    + comboBox1.SelectedItem.ToString() + "='' and exists (select * from " + comboBox3.SelectedItem.ToString() + " where ";
                    DataTable dtbl = myConn.GetSchema(DB2MetaDataCollectionNames.Columns, new String[4] { null, null, (String)tables[comboBox3.SelectedIndex], null });
                    String[] matCols = new String[dtbl.Rows.Count];
                    int i = 0;
                    foreach (DataRow dr in dtbl.Rows)
                    {
                        matCols[i] = dr["column_name"].ToString();
                        i++;
                    }

                    for (int j = 0; j < dtbl.Rows.Count; j++)
                    {
                        //Console.WriteLine((toMatch.Rows[j]["data_type_name"].ToString()));
                        //if (toMatch.Rows[j]["data_type_name"].ToString()=="VARCHAR" && origCols.Rows[j]["data_type_name"].ToString()=="VARCHAR")
                        comm.CommandText += "upper(" + comboBox3.SelectedItem.ToString() + "." + matCols[j] + ")=upper(" +
                            briefTblName + "." + comboBox1.SelectedItem.ToString() + ") or ";
                    }
                    comm.CommandText = comm.CommandText.Substring(0, comm.CommandText.Length - 4) + ");";
                    try
                    {
                        comm.ExecuteNonQuery();
                        Console.Write(comm.CommandText);
                        Console.WriteLine("");
                    }
                    catch (InvalidOperationException excpt)
                    {
                        Console.WriteLine(excpt.Message);
                        Console.Write(comm.CommandText);
                        Console.WriteLine("");
                    }
                    catch (DB2Exception db2e2)
                    {
                        Console.WriteLine(db2e2.Message);
                        Console.Write(comm.CommandText);
                        Console.WriteLine("");
                    }
                    comm.CommandText = "update " + briefTblName + " set spell_err_" + spErrs.Count + "=1 where " + comboBox1.SelectedItem.ToString() +
                        "='' or not exists (select * from " + comboBox3.SelectedItem.ToString() + " where ";
                    for (int j = 0; j < dtbl.Rows.Count; j++)
                    {
                        //if (toMatch.Rows[j]["data_type_name"].ToString() == "VARCHAR" && origCols.Rows[j]["data_type_name"].ToString() == "VARCHAR")
                        comm.CommandText += "upper(" + comboBox3.SelectedItem.ToString() + "." + matCols[j] + ")=upper(" +
                            briefTblName + "." + comboBox1.SelectedItem.ToString() + ") or ";
                    }
                    comm.CommandText = comm.CommandText.Substring(0, comm.CommandText.Length - 4) + ");";
                    try
                    {
                        comm.ExecuteNonQuery();
                        Console.Write(comm.CommandText);
                        Console.WriteLine("");
                    }
                    catch (InvalidOperationException excpt)
                    {
                        Console.WriteLine(excpt.Message);
                        Console.Write(comm.CommandText);
                        Console.WriteLine("");
                    }
                    catch (DB2Exception db2e2)
                    {
                        Console.WriteLine(db2e2.Message);
                        Console.Write(comm.CommandText);
                        Console.WriteLine("");
                    }
                    listBox1.Items.Add("Spelling-" + spErrs.Count.ToString() + ". " + comboBox3.SelectedItem.ToString());
                }
                if (radioButton2.Checked)
                {
                    curErr[2] = "categorization";
                    catErrs.Add(comboBox1.SelectedItem.ToString() + " " + nErrs);
                    catMatches.Add(comboBox3.SelectedItem.ToString());
                    catRefs.Add((String)curColumns[comboBox2.SelectedIndex]);
                    DB2Command comm = new DB2Command("alter table " + briefTblName + " add categ_err_" + catErrs.Count + " num;", myConn);
                    try
                    {
                        comm.ExecuteNonQuery();
                    }
                    catch (InvalidOperationException excpt)
                    {
                        Console.WriteLine(comm.CommandText);
                        Console.WriteLine(excpt.Message);
                    }
                    catch (DB2Exception db2e)
                    {
                        Console.WriteLine(comm.CommandText);
                        Console.WriteLine(db2e.Message);
                    }
                    comm.CommandText = "update " + briefTblName + " set categ_err_" + catErrs.Count + "=0 where not "
                    + comboBox1.SelectedItem.ToString() + "='' and exists (select * from " + comboBox3.SelectedItem.ToString() + " where ";
                    DataTable dtbl = myConn.GetSchema(DB2MetaDataCollectionNames.Columns, new String[4] { null, null, (String)tables[comboBox3.SelectedIndex], null });
                    String[] matCols = new String[dtbl.Rows.Count];
                    int i = 0;
                    foreach (DataRow dr in dtbl.Rows)
                    {
                        matCols[i] = dr["column_name"].ToString();
                        i++;
                    }

                    for (int j = 0; j < dtbl.Rows.Count; j++)
                    {
                        comm.CommandText += "upper(" + comboBox3.SelectedItem.ToString() + "." + matCols[j] + ")=upper(" +
                            briefTblName + "." + comboBox1.SelectedItem.ToString() + ") or ";
                    }
                    comm.CommandText = comm.CommandText.Substring(0, comm.CommandText.Length - 4) + ");";
                    try
                    {
                        comm.ExecuteNonQuery();
                        Console.Write(comm.CommandText);
                        Console.WriteLine("");
                    }
                    catch (InvalidOperationException excpt)
                    {
                        Console.WriteLine(excpt.Message);
                        Console.Write(comm.CommandText);
                        Console.WriteLine("");
                    }
                    catch (DB2Exception db2e2)
                    {
                        Console.WriteLine(db2e2.Message);
                        Console.Write(comm.CommandText);
                        Console.WriteLine("");
                    }
                    comm.CommandText = "update " + briefTblName + " set categ_err_" + catErrs.Count + "=1 where " + comboBox1.SelectedItem.ToString() +
                        "='' or not exists (select * from " + comboBox3.SelectedItem.ToString() + " where ";
                    for (int j = 0; j < dtbl.Rows.Count; j++)
                    {
                        //if (toMatch.Rows[j]["data_type_name"].ToString() == "VARCHAR" && origCols.Rows[j]["data_type_name"].ToString() == "VARCHAR")
                        comm.CommandText += "upper(" + comboBox3.SelectedItem.ToString() + "." + matCols[j] + ")=upper(" +
                            briefTblName + "." + comboBox1.SelectedItem.ToString() + ") or ";
                    }
                    comm.CommandText = comm.CommandText.Substring(0, comm.CommandText.Length - 4) + ");";
                    try
                    {
                        comm.ExecuteNonQuery();
                        Console.Write(comm.CommandText);
                        Console.WriteLine("");
                    }
                    catch (InvalidOperationException excpt)
                    {
                        Console.WriteLine(excpt.Message);
                        Console.Write(comm.CommandText);
                        Console.WriteLine("");
                    }
                    catch (DB2Exception db2e2)
                    {
                        Console.WriteLine(db2e2.Message);
                        Console.Write(comm.CommandText);
                        Console.WriteLine("");
                    }
                    listBox1.Items.Add("Categorical-"+catErrs.Count.ToString() + ". " + comboBox3.SelectedItem.ToString());
                }
                /*errors.Add(curErr);
                DataTable origCols = myConn.GetSchema(DB2MetaDataCollectionNames.Columns, new String[4] { null, null, briefTblName, null });
                allColumns.Insert(comboBox1.SelectedIndex + 1, comboBox1.SelectedItem.ToString() + "_ref");
                whoseRefs[comboBox1.SelectedIndex].Add(comboBox1.SelectedItem.ToString() + "_ref");
                listBox1.Items.Add(nErrs.ToString() + ". " + curErr[1] + " - " + comboBox3.SelectedItem.ToString() + " - " + curErr[2]);
                DB2Command command = new DB2Command("alter table " + briefTblName + " add error" + nErrs + " num;", myConn);
                try
                {
                    command.ExecuteNonQuery();
                }
                catch (InvalidOperationException excpt)
                {
                    Console.WriteLine(excpt.Message);
                }
                catch (DB2Exception db2e)
                {
                    Console.WriteLine(db2e.Message);
                }
                DataTable dt = myConn.GetSchema(DB2MetaDataCollectionNames.Columns, new String[4] { null, null, comboBox3.SelectedItem.ToString(), null });
                String[] matchCols = new String[dt.Rows.Count];
                for (int i = 0; i < dt.Rows.Count; i++ )
                {
                    matchCols[i] = dt.Rows[i]["column_name"].ToString();
                }
                String errDescr = "error" + nErrs;
                whoseErrs[comboBox1.SelectedIndex].Add(errDescr);
                command.CommandText = "update " + briefTblName + " set error" + nErrs + "=0 where not "
                    + comboBox1.SelectedItem.ToString() + "='' and exists (select * from " + comboBox3.SelectedItem.ToString() + " where ";
                for (int j = 0; j < dt.Rows.Count; j++)
                {
                    //Console.WriteLine((toMatch.Rows[j]["data_type_name"].ToString()));
                    //if (toMatch.Rows[j]["data_type_name"].ToString()=="VARCHAR" && origCols.Rows[j]["data_type_name"].ToString()=="VARCHAR")
                    command.CommandText += "upper(" + comboBox3.SelectedItem.ToString() + "." + matchCols[j] + ")=upper(" + 
                        briefTblName + "." + comboBox1.SelectedItem.ToString() + ") or ";
                }
                command.CommandText = command.CommandText.Substring(0, command.CommandText.Length - 4) + ");";
                try
                {
                    command.ExecuteNonQuery();
                    Console.Write(command.CommandText);
                    Console.WriteLine("");
                }
                catch (InvalidOperationException excpt)
                {
                    Console.WriteLine(excpt.Message);
                    Console.Write(command.CommandText);
                    Console.WriteLine("");
                }
                catch (DB2Exception db2e2)
                {
                    Console.WriteLine(db2e2.Message);
                    Console.Write(command.CommandText);
                    Console.WriteLine("");
                }
                command.CommandText = "update " + briefTblName + " set error" + nErrs + "=1 where " + comboBox1.SelectedItem.ToString() + 
                    "='' or not exists (select * from " + comboBox3.SelectedItem.ToString() + " where ";
                for (int j = 0; j < dt.Rows.Count; j++)
                {
                    //if (toMatch.Rows[j]["data_type_name"].ToString() == "VARCHAR" && origCols.Rows[j]["data_type_name"].ToString() == "VARCHAR")
                    command.CommandText += "upper(" + comboBox3.SelectedItem.ToString() + "." + matchCols[j] + ")=upper(" + 
                        briefTblName + "." + comboBox1.SelectedItem.ToString() + ") or ";
                }
                command.CommandText = command.CommandText.Substring(0, command.CommandText.Length - 4) + ");";
                try
                {
                    command.ExecuteNonQuery();
                    Console.Write(command.CommandText);
                    Console.WriteLine("");
                }
                catch (InvalidOperationException excpt)
                {
                    Console.WriteLine(excpt.Message);
                    Console.Write(command.CommandText);
                    Console.WriteLine("");
                }
                catch (DB2Exception db2e2)
                {
                    Console.WriteLine(db2e2.Message);
                    Console.Write(command.CommandText);
                    Console.WriteLine("");
                }*/
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        public void listBox1_MouseOver(Object sender, EventArgs e) { }

        private void button4_Click(object sender, EventArgs e)
        {
            String briefTblName=tableName.Split('\\').Last();
            //do not use selected reference column as possible match if different data type
            //check using the Columns attribute
            Visible = false;
            String[] attrs = new String[catErrs.Count];
            int[] catErrs2=new int[catErrs.Count];
            for (int i = 0; catErrs.Count > i; i++)
            {
                attrs[i] = ((String)catErrs[i]).Split(' ').First();
                catErrs2[i] = Int32.Parse(((string)catErrs[i]).Split(' ').Last());
            }
            String[] categMatches = new String[catMatches.Count];
            for (int i = 0; i < catMatches.Count; i++)
                categMatches[i] = (String)catMatches[i];
            String[] categRefs = new String[catRefs.Count];
            for (int i = 0; i < catRefs.Count; i++)
                categRefs[i] = (String)catRefs[i];
            CatErrSelect ces = new CatErrSelect(myConn, briefTblName, catErrs2, attrs, categMatches, categRefs);
            //CatErrSelect ces = new CatErrSelect(myConn, briefTblName, categErrs, categMatches, categRefs);
            if (ces.ShowDialog() == DialogResult.Cancel)
                Visible = true;
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox3.SelectedIndex >= comboBox3.Items.Count) return;
            comboBox3.BackColor = Color.White;
            comboBox2.Items.Clear();
            curColumns.Clear();
            String shortTblName =comboBox3.SelectedItem.ToString().Split('\\').Last();
            if (!myConn.IsOpen)
                myConn.Open();
            DataTable matchCols = myConn.GetSchema(DB2MetaDataCollectionNames.Columns, new String[] { null, null, (String)tables[comboBox3.SelectedIndex], null });
            foreach (DataRow dr in matchCols.Rows)
            {
                //Console.WriteLine(dr["table_name"]);
                if (!dr["column_name"].ToString().StartsWith("SYS"))
                {
                    curColumns.Add(dr["column_name"].ToString());
                    comboBox2.Items.Add(dr["column_name"]);
                }
            }
            DB2DataAdapter ad = new DB2DataAdapter("select * from " + shortTblName + " fetch first 10 rows only;", myConn);
            DataTable ourData = new DataTable();
            ad.Fill(ourData);
            dataGridView2.DataSource = ourData;
            dataGridView2.Refresh();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox1.BackColor = Color.White;
            for (int i = 0; i < dataGridView1.Columns.Count; i++)
                if (dataGridView1.Columns[i].DefaultCellStyle.BackColor == Color.Red)
                    dataGridView1.Columns[i].DefaultCellStyle.BackColor = Color.White;
            dataGridView1.CurrentCell = dataGridView1[comboBox1.SelectedIndex, 0];
            //dataGridView1.Columns[comboBox1.SelectedIndex].DefaultCellStyle.BackColor = Color.Red;
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            for (int i = 0; i < dataGridView2.Columns.Count; i++)
                if (dataGridView2.Columns[i].DefaultCellStyle.BackColor == Color.Red)
                    dataGridView2.Columns[i].DefaultCellStyle.BackColor = Color.White;
            dataGridView2.CurrentCell = dataGridView2[comboBox2.SelectedIndex, 0];
            //dataGridView2.Columns[comboBox2.SelectedIndex].DefaultCellStyle.BackColor = Color.Red;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            FileDialog fd = new OpenFileDialog();
            fd.Filter = "Comma Separated Values|*.csv";
            if (fd.ShowDialog() == DialogResult.OK)
            {
                textBox2.Text = fd.FileName;
                CSVParser parser = new CSVParser();
                parser.parse(fd.FileName, myConn);
                String shortTblName = fd.FileName.Split('\\').Last().Split('.')[0];
                comboBox3.Items.Add(shortTblName.ToUpper());
                tables.Add(shortTblName);
                comboBox3.SelectedIndex = comboBox3.Items.Count - 1;
                DB2DataAdapter ad = new DB2DataAdapter("select * from " + shortTblName + " fetch first 10 rows only;", myConn);
                DataTable ourData = new DataTable();
                ad.Fill(ourData);
                dataGridView2.DataSource = ourData;
                dataGridView2.Refresh();
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            DupliForm df = new DupliForm(myConn, tableName);
            Visible = false;
            if (df.ShowDialog() == DialogResult.Cancel)
                Visible = true;
        }
    }
}
