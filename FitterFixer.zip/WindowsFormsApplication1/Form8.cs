﻿/*@author Alex Trichtchenko
 * Not for commercial use
 */

using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IBM.Data.DB2;

namespace WindowsFormsApplication1
{
    public partial class Form8 : Form
    {
        ArrayList[] whoseErrs;
        DB2Connection db;
        String tblName;
        int[] catErrs;
        int catErr;
        String[] attrs;
        String attr;
        //ArrayList lookupInfo;
        ArrayList lookupTbls;
        ArrayList catColumns;
        ArrayList descColumns;
        String[] categMatches;
        String[] categRefs;
        String categMatch;
        String categRef;
        String wordTbl;
        String synTbl;
        String[] wordRef;
        String wordCol;
        String synCol;
        double minConf;
        double minSig;
        double synConf;
        double synConfBoost;
        public Form8()
        {
            InitializeComponent();
        }
        public Form8(ArrayList lookupTbls, DB2Connection db, String tblName, int catErr,
             String attr, String categMatch, String categRef)
        {
            InitializeComponent();
            this.db = db;
            this.tblName = tblName;
            this.categMatch = categMatch;
            this.categRef = categRef;
            this.lookupTbls = lookupTbls;
            dataGridView1.AutoGenerateColumns = true;
            dataGridView2.AutoGenerateColumns = true;
            this.catErr = catErr;
            this.attr = attr;
            dataGridView3.AutoGenerateColumns = true;
            dataGridView4.AutoGenerateColumns = true;
            groupBox1.Enabled = false;
            textBox3.Text = attr;
            textBox4.Text="C:\\Program Files";
            if (!db.IsOpen)
                db.Open();
            DataTable tmp = db.GetSchema(DB2MetaDataCollectionNames.Tables);
            for (int i = 0; i < lookupTbls.Count; i++)
            {
                comboBox2.Items.Add((String)lookupTbls[i]);
            }
            /*comboBox5.Items.Add(".");
            comboBox5.Items.Add("/");
            comboBox5.Items.Add(",");
            comboBox5.Items.Add("-");
            comboBox5.Items.Add("<space>");
            comboBox5.Items.Add("<none>");
            comboBox5.SelectedIndex = 0;*/
            languageBox.Items.Add("English");
            languageBox.Items.Add("French");
            languageBox.SelectedIndex = 0;
            minConf = 0.50;
            synConf = (double)0.01;
            synConfBoost = 0.80;
            minSig = (double) 15 / 100;
            DataTable dtbl = new DataTable();
            DB2DataAdapter ad = new DB2DataAdapter("select " + categRef +
                " from " + categMatch + ";", db);
            ad.Fill(dtbl);
            int maxLgt = 0;
            for (int i = 0; i < dtbl.Rows.Count; i++)
                if (dtbl.Rows[i][0].ToString().Length > maxLgt)
                    maxLgt = dtbl.Rows[i][0].ToString().Length;
            
            DataTable cols = db.GetSchema(DB2MetaDataCollectionNames.Columns,
                new String[] { null, null, categMatch, null });
            Console.WriteLine(categMatch);
            for (int i = 0; i < cols.Rows.Count; i++)
                comboBox7.Items.Add(cols.Rows[i]["column_name"].ToString());

        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox2.SelectedItem != null)
            {
                DB2DataAdapter db2c = new DB2DataAdapter("select " + comboBox3.SelectedItem.ToString() + ", " + comboBox4.SelectedItem.ToString()
                    + " from " + comboBox2.SelectedItem.ToString() + " fetch first 10 rows only;", db);
                DataTable dt = new DataTable();
                db2c.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            /*String delim="";
            if (comboBox5.SelectedItem.ToString()!=null)
                delim = comboBox5.SelectedItem.ToString();
            char delimiter;
            if (delim == "<space>") delimiter = ' ';
            else if (delim == "<none>") delimiter = '\0';
            else delimiter = delim.ToCharArray()[0];
            if (delim == "") delimiter = '.';//default*/
            char delimiter = '.';
            DataTable dtbl = new DataTable();
            DB2DataAdapter ad = new DB2DataAdapter("select "+categRef+", "+comboBox7.SelectedItem+
                " from " + categMatch + ";",db);
            ad.Fill(dtbl);
            DataTable allData = new DataTable();
            DB2DataAdapter ad2 = new DB2DataAdapter("select " + comboBox3.SelectedItem.ToString() + ", " + comboBox4.SelectedItem.ToString() + 
                " from " + comboBox2.SelectedItem.ToString() + ";", db);
            ad2.Fill(allData);
            String[] basicCats = new String[dtbl.Rows.Count];
            String[] basicDescs = new String[dtbl.Rows.Count];
            int maxLgt = 0;
            for (int i = 0; i < dtbl.Rows.Count; i++)
                if (dtbl.Rows[i][0].ToString().Length > maxLgt)
                    maxLgt = dtbl.Rows[i][0].ToString().Length;
            for (int i = 0; i < basicCats.Length; i++)
            {
                basicCats[i] = dtbl.Rows[i][0].ToString();
                basicDescs[i] = dtbl.Rows[i][1].ToString().Substring(basicCats[i].Length+2);
                while (basicCats[i].Length < maxLgt)
                    basicCats[i] = "0" + basicCats[i];
            }
            String[] codes = new String[basicCats.Length + allData.Rows.Count];
            String[] descs = new String[basicDescs.Length + allData.Rows.Count];
            for (int i = 0; i < allData.Rows.Count; i++)
            {
                String[] tmp = allData.Rows[i][0].ToString().Split(delimiter);
                for (int j = 0; j < tmp.Length; j++)
                    codes[i] += tmp[j];
                descs[i] = allData.Rows[i][1].ToString();
            }
            for (int i = allData.Rows.Count; i < allData.Rows.Count + basicCats.Length; i++)
            {
                codes[i] = basicCats[i-allData.Rows.Count];
                descs[i] = basicDescs[i-allData.Rows.Count];
            }
            ClassificationTree ct = new ClassificationTree(new ClassTreeNode("","",db),db);
            DataTable dt = new DataTable(); //list of non-empty improper entries
            /*DB2DataAdapter db2a = new DB2DataAdapter("select distinct " + attr + " from " + tblName +
                " where error" + catErr + "=1 and not " + attr + "='';", db);
            db2a.Fill(dt);*/
            DB2DataAdapter db2ada = new DB2DataAdapter("select distinct " + attr + " from " + tblName +
                " where categ_err_" + catErr + "=1 and not " + attr + "='';", db);
            db2ada.Fill(dt);

            ct.populate(db, codes, descs, delimiter);
            String[] badEntries = new String[dt.Rows.Count];
            for (int j = 0; j < dt.Rows.Count; j++)
            {
                badEntries[j] = dt.Rows[j][0].ToString().ToLower();
            }
            if (languageBox.SelectedIndex == 0)
            {
                    DataTable tables = db.GetSchema(DB2MetaDataCollectionNames.Tables);
                    String[] tbls = new String[tables.Rows.Count];
                    for (int i = 0; i < tbls.Length; i++)
                        tbls[i] = tables.Rows[i]["table_name"].ToString();
                    if (!tbls.Contains("NINDEX") || !tbls.Contains("NDATA"))
                    {
                        WordNetParser p = new WordNetParser("C:\\Program Files", db);
                        label4.Text = "Parsing nouns...";
                        p.parseIndex();
                        label4.Text = "Parsing hyponyms...";
                        p.parseData();
                        label4.Text = "Done";    
                    }
                    /*if (!tbls.Contains("NTEXTDATA"))
                    {
                        DB2Command hypTblCreate = new DB2Command("create table ntextdata (word_id varchar(8), hyponym varchar(256));", db);
                        try
                        {
                            hypTblCreate.ExecuteNonQuery();
                        }
                        catch (InvalidOperationException ex)
                        {
                            Console.WriteLine(hypTblCreate.CommandText);
                            Console.WriteLine(ex.Message);
                        }
                        catch (DB2Exception ex) {
                            Console.WriteLine(hypTblCreate.CommandText);
                            Console.WriteLine(ex.Message);
                        }
                        DB2Command hypTblPopulate = new DB2Command("insert into ntextdata (select ndata.word_id, nindex.word from ndata, nindex where ndata.hyponym_id=nindex.word_id;", db);
                        try
                        {
                            hypTblPopulate.ExecuteNonQuery();
                        }
                        catch (InvalidOperationException ex)
                        {
                            Console.WriteLine(hypTblPopulate.CommandText);
                            Console.WriteLine(ex.Message);
                        }
                        catch (DB2Exception ex)
                        {
                            Console.WriteLine(hypTblPopulate.CommandText);
                            Console.WriteLine(ex.Message);
                        }
                    }*/
                    ArrayList simpleBadEntries = new ArrayList();
                    for (int i = 0; i < badEntries.Length; i++)
                        if (!badEntries[i].Contains(' ') && !simpleBadEntries.Contains(badEntries[i]))
                        {
                            simpleBadEntries.Add(badEntries[i]);
                            if (badEntries[i].EndsWith("s"))
                                simpleBadEntries.Add(singular(badEntries[i], "English"));
                        }
                    String[] badWords = new String[simpleBadEntries.Count];
                    for (int i = 0; i < simpleBadEntries.Count; i++)
                        badWords[i] = (String)simpleBadEntries[i];
                    /*ArrayList hypLists = new ArrayList();
                    DB2DataAdapter hypAd = new DB2DataAdapter("select distinct word, hyponym from nindex, ntextdata where"
                        +" nindex.word_id=ndata.word_id and word in (",db);
                   
                    for (int i = 0; i < badWords.Length; i++) {
                        if (badWords[i].Contains('\''))
                        {
                            String[] tmp = badWords[i].Split('\'');
                            badWords[i] = "";
                            for (int j = 0; j < tmp.Length; j++)
                                badWords[i] = "''" + tmp[j];
                            badWords[i] = badWords[i].Substring(2);
                        }
                        hypAd.SelectCommand.CommandText +="'"+badWords[i]+"'" + ",";
                    }
                    hypAd.SelectCommand.CommandText = hypAd.SelectCommand.CommandText.Substring(0, hypAd.SelectCommand.CommandText.Length - 1)+");";
                    DataTable hypData = new DataTable();
                    try
                    {
                        hypAd.Fill(hypData);
                    }
                    catch (InvalidOperationException ex)
                    {
                        Console.WriteLine(hypAd.SelectCommand.CommandText);
                        Console.WriteLine(ex.Message);
                    }
                    catch (DB2Exception ex)
                    {
                        Console.WriteLine(hypAd.SelectCommand.CommandText);
                        Console.WriteLine(ex.Message);
                    }
                    foreach (String s in badWords)
                    {
                        ArrayList tmpList=new ArrayList();
                        while (hypData.Rows.Count > 0 && hypData.Rows[0][0].ToString() == s)
                        {
                            tmpList.Add(hypData.Rows[0][1].ToString());
                            hypData.Rows.RemoveAt(0);
                        }
                        hypLists.Add(tmpList);
                    }
                    int maxHyp = 0;
                    foreach (ArrayList l in hypLists)
                    {
                        if (l.Count > maxHyp)
                            maxHyp = l.Count;
                    }
                    String[,] hyps = new String[badWords.Length, maxHyp];
                    for (int i = 0; i < hypLists.Count; i++)
                        for (int j = 0; j < ((ArrayList)hypLists[i]).Count; j++)
                            hyps[i, j] = (String)((ArrayList)hypLists[i])[j];
                        
                    double[,] scores = ct.scoreHyponyms(badWords, hyps);
*/
                    double[,] scores=new double[badWords.Length,ct.getRoot().getChildren().Count];
                    for (int i = 0; i < badWords.Length; i++)
                    {
                        double[] tmpScores = ct.scoreHyponyms(singular(badWords[i],"English"));
                        for (int j = 0; j < tmpScores.Length; j++)
                            scores[i, j] = tmpScores[j];
                    }
                    String[] winners = new String[badWords.Length];
                    DataTable results = new DataTable();
                    DataColumn entryF = new DataColumn("entry");
                    DataColumn resultF = new DataColumn("suggestion");
                    results.Columns.Add(entryF);
                    results.Columns.Add(resultF);
                    for (int i = 0; i < badWords.Length; i++)
                    {
                        double total = 0;
                        for (int j = 0; j < ct.getRoot().getChildren().Count; j++)
                            total += scores[i, j];
                        for (int j = 0; j < ct.getRoot().getChildren().Count; j++)
                        {
                            scores[i, j] /= total;
                            if (scores[i, j] > 0.5)
                            {
                                winners[i] = ((ClassTreeNode)ct.getRoot().getChildren()[j]).getCode() + ". " + ((ClassTreeNode)ct.getRoot().getChildren()[j]).getDescription();
                                DataRow dr = results.NewRow();
                                dr["entry"] = badWords[i];
                                dr["suggestion"] = winners[i];
                                results.Rows.Add(dr);
                            }
                        }
                    }
                    Form9 f9 = new Form9(db, results, tblName, attr, catErr, categMatch);
                    Visible = false;
                    if (f9.ShowDialog() == DialogResult.Cancel)
                        Visible = true;
                    if (f9.ShowDialog() == DialogResult.OK)
                    {
                        comboBox2.SelectedIndex--;
                        comboBox2.Items.RemoveAt(comboBox2.SelectedIndex + 1);
                    }
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            DB2DataAdapter db2a = new DB2DataAdapter("select * from " + comboBox2.SelectedItem.ToString() + ";",db);
            DataTable curTbl = new DataTable();
            db2a.Fill(curTbl);
            foreach (DataColumn dc in curTbl.Columns)
            {
                comboBox3.Items.Add(dc.ColumnName);
                comboBox4.Items.Add(dc.ColumnName);
            }
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            DictForm df = new DictForm(db);
            if (df.ShowDialog() == DialogResult.OK)
            {
                this.wordRef = df.wordRef;
                this.wordTbl = df.wordTbl;
                this.synTbl = df.synTbl;
                this.wordCol = df.wordCol;
                this.synCol = df.synCol;
                DB2DataAdapter db2a = new DB2DataAdapter("select * from " + wordTbl + " fetch first 10 rows only;", db);
                DataTable dt = new DataTable();
                db2a.Fill(dt);
                dataGridView3.DataSource = dt;
                DB2DataAdapter db2a2 = new DB2DataAdapter("select * from " + synTbl + " fetch first 10 rows only;", db);
                DataTable dt2 = new DataTable();
                db2a.Fill(dt2);
                dataGridView4.DataSource = dt2;
                this.Visible = true;
            }
        }

        private void comboBox7_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable dtbl = new DataTable();
            DB2DataAdapter db2a = new DB2DataAdapter("select " + comboBox7.SelectedItem.ToString() + " from " + categMatch + " fetch first 10 rows only;", db);
            db2a.Fill(dtbl);
            dataGridView2.DataSource = dtbl;
            if (comboBox7.SelectedItem.ToString() == categRef)
                comboBox7.BackColor = Color.Red;
            else
                comboBox7.BackColor = Color.White;
        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        public String singular(String pl, String language)
        {
            if (language == "English")
            {
                if (pl.EndsWith("buses") || pl.EndsWith("gases"))
                    return pl.Substring(0, pl.Length - 2);
                else if (pl.EndsWith("sses") || pl.EndsWith("xes"))
                    return pl.Substring(0, pl.Length - 2);
                else if (pl.EndsWith("ies"))
                    return pl.Substring(0, pl.Length - 3) + "y";
                else if (pl.EndsWith("s"))
                    return pl.Substring(0, pl.Length - 1);
                else if (pl.EndsWith("i"))
                    return pl.Substring(0, pl.Length - 1) + "us";
                else
                    return pl;
            }
            return pl;
        }

    }
}
