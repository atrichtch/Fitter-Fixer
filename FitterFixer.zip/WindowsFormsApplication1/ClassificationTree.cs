﻿/*@author Alex Trichtchenko
 * Not for commercial use
 */

using System;
using System.Collections.Generic;
using System.Collections;
using System.IO;
using System.Linq;
using System.Data;
using System.Text;
using IBM.Data.DB2;

namespace WindowsFormsApplication1
{
    class ClassificationTree
    {
        private ClassTreeNode root;
        private int minLength, maxLength;
        private DB2Connection db;

        public ClassificationTree(ClassTreeNode r, DB2Connection db)
        {
            root = new ClassTreeNode(r.getCode(),r.getDescription(),db);
            this.db = db;
        }
        public ClassTreeNode getRoot()
        {
            return root;
        }
        public void populate(DB2Connection db2c, DataTable allData, String codeColumn, String descColumn, char delimiter, char packet)
        {//copy the datatable to 2 arrays then use then to populate the tree
            String[,] data=new String[2,allData.Rows.Count];
            String[] codes = new String[allData.Rows.Count];
            String[] descs = new String[allData.Rows.Count];
            for (int i = 0; i < allData.Rows.Count; i++)
            {
                String[] tmp = allData.Rows[i][0].ToString().Split(delimiter);
                for (int j = 0; j < tmp.Length; j++)
                    codes[i] += tmp[j];
                descs[i] = allData.Rows[i][1].ToString();
                if (i == 0)
                    Console.WriteLine(codes[i] + " " + descs[i]);
            }
            populate(db2c, codes,descs, delimiter);
        }
        public void populate(DB2Connection db2c, String[] codes, String[] descs, char delimiter)
        {
            if (root == null)
                root = new ClassTreeNode("", "",db2c);
            Array.Sort(codes, descs);
            for (int i = 0; i < codes.Count(); i++) //add everything first
                root.addChild(new ClassTreeNode(codes[i], descs[i],db2c));
            for (int i = 0; i < root.getChildren().Count - 1; i++)
            {//examine each node
                String[] childCodesX = new String[codes.Count()];
                String[] childDescsX = new String[descs.Count()];
                int childSize = 0;
                while (i < root.getChildren().Count - 1 && ((ClassTreeNode)root.getChildren()[i + 1]).getCode().StartsWith(((ClassTreeNode)root.getChildren()[i]).getCode()))
                {//remove all nodes that are supposed to be its descendents
                    childCodesX[childSize]=(((ClassTreeNode)root.getChildren()[i + 1]).getCode());
                    childDescsX[childSize]=(((ClassTreeNode)root.getChildren()[i + 1]).getDescription());
                    root.getChildren().RemoveAt(i + 1);
                    childSize++;
                }
                String[] childCodes = new String[childSize];
                String[] childDescs = new String[childSize];
                for (int j = 0; j < childSize; j++)
                {//trim the arrays, so they are sorted properly
                    childCodes[j] = childCodesX[j];
                    childDescs[j] = childDescsX[j];
                }
                ClassificationTree ct = new ClassificationTree((ClassTreeNode)root.getChildren()[i],db); //generate subtree
                ct.populate(db2c, childCodes, childDescs, delimiter); //recursively
                ct.maxLength=this.maxLength;
            }
        }

        public void print(int n)
        {
            for (int j = 0; j < n; j++)
                Console.Write(" ");
            Console.WriteLine(root.getCode() + " " + root.getDescription());
            for (int i = 0; i < root.getChildren().Count; i++)
            {
                ClassificationTree ct = new ClassificationTree((ClassTreeNode)root.getChildren()[i],db);
                ct.print(n+1);
            }
        }

        public void populate(DB2Connection db2c, String[] codes, String[] descs, char delimiter, int minDigits)
        {
            this.db = db2c;
            if (root == null)
                root = new ClassTreeNode("", "",db2c);
            Array.Sort(codes, descs);
            ArrayList tmpCodes = new ArrayList();
            ArrayList tmpDescs = new ArrayList();
            for (int i=0; i<codes.Length; i++)
                if (codes[i].Length >= minDigits)
                {
                    tmpCodes.Add(codes[i]);
                    tmpDescs.Add(descs[i]);
                }
            for (int i = 0; i < tmpCodes.Count; i++) //add everything first
                root.addChild(new ClassTreeNode((String)tmpCodes[i], (String)tmpDescs[i],db2c));
            for (int i = 0; i < root.getChildren().Count - 1; i++)
            {//examine each node
                String[] childCodesX = new String[tmpCodes.Count];
                String[] childDescsX = new String[tmpDescs.Count];
                int childSize = 0;
                while (i < root.getChildren().Count - 1 && ((ClassTreeNode)root.getChildren()[i + 1]).getCode().StartsWith(((ClassTreeNode)root.getChildren()[i]).getCode()))
                {//remove all nodes that are supposed to be its descendents
                    childCodesX[childSize] = (((ClassTreeNode)root.getChildren()[i + 1]).getCode());
                    childDescsX[childSize] = (((ClassTreeNode)root.getChildren()[i + 1]).getDescription());
                    root.getChildren().RemoveAt(i + 1);
                    childSize++;
                }
                String[] childCodes = new String[childSize];
                String[] childDescs = new String[childSize];
                for (int j = 0; j < childSize; j++)
                {//trim the arrays, so they are sorted properly
                    childCodes[j] = childCodesX[j];
                    childDescs[j] = childDescsX[j];
                }
                ClassificationTree ct = new ClassificationTree((ClassTreeNode)root.getChildren()[i],db2c); //generate subtree
                ct.populate(db2c, childCodes, childDescs, delimiter); //recursively
                ct.maxLength = this.maxLength;
            }
        }

        public double[] score(String description, String language)
        {
            double[] scores = new double[root.getChildren().Count];
            for (int i = 0; i < root.getChildren().Count; i++)
                scores[i] = ((ClassTreeNode)root.getChildren()[i]).score(description, language);
            return scores;
        }
        public double[] scoreSynonyms(String[] syns, String language)
        {
            double[] scores = new double[root.getChildren().Count];
            for (int i = 0; i < root.getChildren().Count; i++)
                scores[i] = ((ClassTreeNode)root.getChildren()[i]).scoreSynonyms(syns, language);
            return scores;
        }
        public double[] scoreSynonyms(String entry, String[] syns, String language)
        {
            double[] scores = new double[root.getChildren().Count];
            for (int i = 0; i < root.getChildren().Count; i++)
                scores[i] = ((ClassTreeNode)root.getChildren()[i]).scoreSynonyms(entry, syns, language);
            return scores;
        }
        public double[] scoreSynonyms(String entry, String[] syns, double synConf, String language)
        {
            double[] scores = new double[root.getChildren().Count];
            for (int i = 0; i < root.getChildren().Count; i++)
                scores[i] = ((ClassTreeNode)root.getChildren()[i]).scoreSynonyms(entry, syns,synConf, language);
            return scores;
        }

        public double[,] scoreHash(String[] allEntries)
        {
            double[,] scores = new double[allEntries.Length, root.getChildren().Count];
            String[] plurals = new String[allEntries.Length];
            String[] everything = new String[2 * allEntries.Length];
            for (int i = 0; i < plurals.Length; i++)
                plurals[i] = root.plural(allEntries[i]);
            root.alphabetize();
            for (int i = 0; i < plurals.Length; i++)
            {
                everything[i] = allEntries[i];
                everything[i + allEntries.Length] = plurals[i];
            }
            Array.Sort(everything);
            ArrayList tmp = new ArrayList();
            tmp.Add(everything[0]);
            for (int i = 1; i < everything.Length; i++)
                if (everything[i] != everything[i - 1])
                    tmp.Add(everything[i]);
            String[] stuff = new String[tmp.Count];
            for (int i = 0; i < stuff.Length; i++)
                stuff[i] = (String)tmp[i];
            for (int i = 0; i < root.getChildren().Count; i++)
                ((ClassTreeNode)root.getChildren()[i]).hashGen(stuff);
            for (int i = 0; i < allEntries.Length; i++)
                for (int j = 0; j < root.getChildren().Count; j++)
                    scores[i, j] = ((ClassTreeNode)root.getChildren()[j]).scoreHash(allEntries[i]);
            return scores;
        }

        public double[] scoreHyponyms(String entry)
        {
            double[] scores = new double[root.getChildren().Count];
            for (int i=0; i<scores.Length; i++)
                scores[i]=((ClassTreeNode)root.getChildren()[i]).scoreHyponyms(entry);
            return scores;
        }

        public double[,] scoreHyponyms(String[] allEntries, String[,] hyponyms)
        {
            double[,] scores = new double[allEntries.Length, root.getChildren().Count];
            String[] plurals = new String[allEntries.Length];
            String[] everything = new String[2 * allEntries.Length];
            for (int i = 0; i < plurals.Length; i++)
                plurals[i] = root.plural(allEntries[i]);
            root.alphabetize();
            for (int i = 0; i < plurals.Length; i++)
            {
                everything[i] = allEntries[i];
                everything[i + allEntries.Length] = plurals[i];
            }
            Array.Sort(everything);
            ArrayList tmp = new ArrayList();
            tmp.Add(everything[0]);
            for (int i = 1; i < everything.Length; i++)
                if (everything[i] != everything[i - 1])
                    tmp.Add(everything[i]);
            String[] stuff = new String[tmp.Count];
            for (int i = 0; i < stuff.Length; i++)
                stuff[i] = (String)tmp[i];
            for (int i = 0; i < root.getChildren().Count; i++)
                ((ClassTreeNode)root.getChildren()[i]).hashGen(stuff);
            for (int i = 0; i < allEntries.Length; i++)
            {
                String[] tmpHyp = new String[hyponyms.Length / allEntries.Length];
                for (int j = 0; j < hyponyms.Length / allEntries.Length && hyponyms[i,j]!=null; j++)
                    tmpHyp[j] = hyponyms[i, j];
                for (int j = 0; j < root.getChildren().Count; j++)
                    scores[i, j] = ((ClassTreeNode)root.getChildren()[j]).scoreHyponyms(allEntries[i],tmpHyp);
            }
            return scores;
        }
    }
}
