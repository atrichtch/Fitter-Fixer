﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Text;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using IBM.Data.DB2;
using IBM.Data.DB2Types;
using System.Text.RegularExpressions;


namespace WindowsFormsApplication1
{
    class WordNetParser
    {
        DB2Connection myConn;
        private String dataFileName;
        private String indexFileName;
        private String dataTblName;
        private String indexTblName;
        public WordNetParser(String dir, DB2Connection c)
        {
            dataFileName = dir + "\\WordNet\\2.1\\dict\\data.txt";
            indexFileName = dir + "\\WordNet\\2.1\\dict\\index.txt";
            dataTblName = "ndata";
            indexTblName = "nindex";
            myConn = c;
        }
        public void parseIndex()
        {
            try
            {
                StreamReader reader = new StreamReader(indexFileName, new UTF7Encoding());
                String curLn = "";
                Regex isIndex = new Regex("[0-9]{8}");
                /*int nLns = 0;
                while (!endsInIndex.IsMatch(curLn)) 
                    try
                    {
                        curLn=reader.ReadLine();
                        nLns++;
                    }
                    catch { }*/
                DB2Command create = new DB2Command("create table nindex(word varchar(256), word_id varchar(8));", myConn);
                try
                {
                    create.ExecuteNonQuery();
                }
                catch (InvalidOperationException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (DB2Exception e)
                {
                    Console.WriteLine(e.Message);
                }
                DB2Command populate = new DB2Command("", myConn);
                curLn = reader.ReadLine();
                while (curLn != null)
                {
                    String[] entries = curLn.Split(' ');
                    if (entries[0].Contains("'"))
                    {
                        String[] tmp = entries[0].Split('\'');
                        entries[0] = "";
                        for (int i = 0; i < tmp.Length; i++)
                            entries[0] += "''" + tmp[i];
                        entries[0] = entries[0].Substring(2);
                    }
                    if (entries[0].Contains("_"))
                    {
                        String[] tmp = entries[0].Split('_');
                        entries[0] = "";
                        for (int i = 0; i < tmp.Length; i++)
                            entries[0] += " " + tmp[i];
                        entries[0] = entries[0].Substring(1);
                    }
                    String tmpCmd = "insert into nindex values ('" + entries[0] + "'";
                    for (int i = 0; i < entries.Length; i++)
                        if (isIndex.IsMatch(entries[i]))
                        {
                            populate.CommandText = tmpCmd + ", " + entries[i] + ");";
                            try
                            {
                                //Console.WriteLine("Passing: \n"+populate.CommandText);
                                populate.ExecuteNonQuery();
                            }
                            catch (InvalidOperationException e)
                            {
                                Console.WriteLine(populate.CommandText);
                                Console.WriteLine(e.Message);
                            }
                            catch (DB2Exception e)
                            {
                                Console.WriteLine(populate.CommandText);
                                Console.WriteLine(e.Message);
                            }
                        }
                    curLn = reader.ReadLine();
                }
            }
            catch (FileNotFoundException e)
            {
                MessageBox.Show("Error - WordNet not installed");
            }
        }
        public void parseData()
        {
            StreamReader reader = new StreamReader(dataFileName, new UTF7Encoding());
            String curLn = "";
            /*Regex startsWithIndex = new Regex("^[0-9]{8}");
            while (!startsWithIndex.IsMatch(curLn))
                try
                {
                    curLn = reader.ReadLine();
                }
                catch { }*/
            DB2Command create = new DB2Command("create table ndata(word_id varchar(8), hyponym_id varchar(8));", myConn);
            try
            {
                create.ExecuteNonQuery();
            }
            catch (InvalidOperationException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (DB2Exception e)
            {
                Console.WriteLine(e.Message);
            }
            DB2Command populate = new DB2Command("", myConn);
            curLn = reader.ReadLine();
            while (curLn != null)
            {
                String[] entries = curLn.Split(' ');
                String tmpCmd = "insert into ndata values (" + entries[0];
                for (int i = 0; i < entries.Length-1; i++)
                    if (entries[i]=="~")
                    {
                        populate.CommandText = tmpCmd + ", " + entries[i+1] + ");";
                        try
                        {
                            //Console.WriteLine("Passing: \n"+populate.CommandText);
                            populate.ExecuteNonQuery();
                        }
                        catch (InvalidOperationException e)
                        {
                            Console.WriteLine(e.Message);
                        }
                        catch (DB2Exception e)
                        {
                            Console.WriteLine(e.Message);
                        }
                    }
                curLn = reader.ReadLine();
            }
        }
    }
}
