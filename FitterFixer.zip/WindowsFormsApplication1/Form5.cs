﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;
using IBM.Data.DB2;
using IBM.Data.DB2Types;
using System.Text.RegularExpressions;

namespace WindowsFormsApplication1
{
    public partial class Form5 : Form
    {
        //bool existingDB;
        private DB2Connection localEstab;
        public Form5()
        {
            InitializeComponent();
        }

        public Form5(DB2Connection db2c, string tableName)
        {
            localEstab = db2c;
        }

        public Form5(DB2Connection db2c, string tableName, String[] cols)
        {
            localEstab = db2c;
            InitializeComponent();
            textBox1.Text = tableName;
            for (int i=0; i<cols.Length; i++)
                comboBox1.Items.Add(cols[i]);
            
        }
        private void Form5_Load(object sender, EventArgs e)
        {
            //if (existingDB)
            {
                button3.Enabled = true;
                button5.Enabled = true;
                button6.Enabled = true;
                DataTable dt = localEstab.GetSchema(DB2MetaDataCollectionNames.Tables);
                foreach (DataRow dr in dt.Rows)
                {
                    //Console.WriteLine(dr["table_name"]);
                    if (!dr["table_name"].ToString().StartsWith("SYS"))
                        listBox1.Items.Add(dr["table_name"]);
                }
            }
            /*if (!existingDB)
            {
                button3.Enabled = true;
                button5.Enabled = false;
                button6.Enabled = true;
            }*/
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //if (existingDB)
            {
                CSVParser parser = new CSVParser();
                parser.parse("", localEstab);
            }
        }
        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //if (existingDB)
            {
                CSVParser parser = new CSVParser();
                parser.parse("", localEstab);
            }

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void DataGroup_Enter(object sender, EventArgs e)
        {

        }
    }
}
