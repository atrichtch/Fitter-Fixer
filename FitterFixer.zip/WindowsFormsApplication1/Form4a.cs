﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IBM.Data.DB2;
using IBM.Data.DB2Types;
using System.Threading;


namespace WindowsFormsApplication1
{
    public partial class Form4 : Form
    {
        DB2Connection myConn;
        String tableName;
        int nErrs;
        String[] cols;
        public Form4()
        {
            InitializeComponent();
        }

        public Form4(DB2Connection dc)
        {
            myConn = dc;
            InitializeComponent();
        }

        public Form4(DB2Connection dc, String s)
        {
            myConn = dc;
            tableName = s;
            InitializeComponent();
        }

        public Form4(DB2Connection dc, String s, bool fromFile)
        {
            myConn = dc;
            tableName = s;
            if (fromFile)
                textBox1.Text = tableName;
            InitializeComponent();
        }
        public void ThreadProc()
        {
            Application.Run(this);
        } 
        public new void Show ()
        {
            Thread t = new Thread(new ThreadStart(ThreadProc));
            t.Start();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form4_Load(object sender, EventArgs e)
        {
            textBox1.Text = tableName;
            dataGridView1.AutoGenerateColumns = true;
            String shortTblName = tableName.Split('\\').Last();
            DataTable dt = myConn.GetSchema(DB2MetaDataCollectionNames.Columns, new String[4] {null, null, shortTblName, null});
            cols = new String[dt.Rows.Count];
            int i=0;
            foreach (DataRow dr in dt.Rows)
            {
                cols[i] = dr["column_name"].ToString();
                i++;
            }
            DB2DataAdapter ad = new DB2DataAdapter("select * from " + shortTblName + " fetch first 10 rows only;", myConn);
            DataTable ourData = new DataTable();
            ad.Fill(ourData);
            dataGridView1.DataSource = ourData;
            dataGridView1.Refresh();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Visible = false;
            if (radioButton1.Checked)
            {
                Form6 f6 = new Form6(null, null, null, 0);
            }
            if (radioButton2.Checked)
            {
                Form5 f5 = new Form5(myConn, tableName, cols);
                if (f5.ShowDialog() == DialogResult.Cancel) {
                    Visible = true;
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        public void listBox1_MouseOver(Object sender, EventArgs e) { }
    }
}
