﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Data;
using IBM.Data.DB2;
using IBM.Data.DB2Types;

namespace WindowsFormsApplication1
{
    class HypoTreeNode
    {
        private String id;
        private String[] word;
        private HypoTreeNode[] children;
        private ClassTreeNode host;
        private String[] hyponyms;
        public String[] getHyponyms()
        {
            ArrayList hypList = new ArrayList();
            hypList.AddRange(word);
            for (int i = 0; i < children.Length; i++)
                hypList.AddRange(children[i].getHyponyms());
            String[] hyponyms = new String[hypList.Count];
            for (int i = 0; i < hyponyms.Length; i++)
                hyponyms[i] = (String)hypList[i];
            return hyponyms;
        }
        public HypoTreeNode(String id, DB2Connection db, ClassTreeNode host)
        {
            this.id=id;
            DB2DataAdapter wordAda = new DB2DataAdapter("select word from nindex where word_id=" + id, db);
            DataTable dt = new DataTable();
            wordAda.Fill(dt);
            word=new String[dt.Rows.Count];
            for (int i = 0; i < dt.Rows.Count; i++)
                word[i] = dt.Rows[i][0].ToString();
            DB2DataAdapter hypAda = new DB2DataAdapter("select hyponym_id from ndata where word_id=" + id, db);
            DataTable hypTbl=new DataTable();
            hypAda.Fill(hypTbl);
            children = new HypoTreeNode[hypTbl.Rows.Count];
            for (int i = 0; i < children.Length; i++)
                children[i] = new HypoTreeNode(hypTbl.Rows[i][0].ToString(), db, host);
            this.host = host;
        }
        public double score()
        {
            double score = 0;
            for (int i = 0; i < word.Length; i++)
            {
                score += host.scoreHash(word[i]);
                for (int j = 0; j < children.Length; j++)
                    score += children[i].score() / children.Length;
            }
            return score;
        }
    }
}
