﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using IBM.Data.DB2;
using IBM.Data.DB2Types;

namespace WindowsFormsApplication1
{
    class TableManipulations
    {
        public DB2Connection conn;
        public TableManipulations(DB2Connection c)
        {
            this.conn = c;
        }
        public void CopyTables(String source, String destination)
        {
            DB2DataAdapter sourceAd = new DB2DataAdapter(new DB2Command("select * from " + source + ";",conn));
            DataTable sourceTab = conn.GetSchema(DB2MetaDataCollectionNames.Columns, new String[4] { null, null, source, null });
       
            String creation="";
            foreach (DataRow dc in sourceTab.Rows)
            {
                creation += ", "+dc["column_name"] + " " + dc["data_type_name"];
                if (dc["data_type_name"].ToString()=="VARCHAR")
                    creation += "(" + dc["column_size"] + ")";
            }
            creation = creation.Substring(2);
            DB2Command create= new DB2Command("create table "+destination+" ("+creation+");", conn);
            try
            {
                create.ExecuteNonQuery();
            }
            catch (InvalidOperationException ioe)
            {
                Console.WriteLine(create.CommandText);
                Console.WriteLine(ioe.Message);
            }
            catch (DB2Exception db2e)
            {
                Console.WriteLine(create.CommandText);
                Console.WriteLine(db2e.Message);
            }
            DB2Command populate = new DB2Command("insert into " + destination + " (select * from " + source + ");", conn);
            try
            {
                populate.ExecuteNonQuery();
            }
            catch (InvalidOperationException ioe)
            {
                Console.WriteLine(ioe.Message);
            }
            catch (DB2Exception db2e)
            {
                Console.WriteLine(db2e.Message);
            }
        }
        public void AddColumnsAt(String source, String[] columns, String[] types, int[] indeces)
        {
            DB2DataAdapter sourceAd = new DB2DataAdapter(new DB2Command("select * from " + source + ";",conn));
            DataTable sourceTab = conn.GetSchema(DB2MetaDataCollectionNames.Columns, new String[4] { null, null, source, null });
            String insertion = ""; //prepare the sql command for inserting the column at the right place
            String repop = ""; //prepare the sql command for repopulating the table
            System.Collections.IEnumerator colEn = sourceTab.Rows.GetEnumerator();
            //int i = 0;
            //int j = 0;
            for (int i = 0; i < indeces[0]; i++)
            {
                insertion += sourceTab.Rows[i]["column_name"] + " " + sourceTab.Rows[i]["data_type_name"]; //add column name and type
                repop += sourceTab.Rows[i]["column_name"] + ", "; //add column name
            }
            for (int j = 0; j < indeces.Count() - 1; j++)
            {
                for (int i = indeces[j]; i < indeces[j + 1]; i++)
                {
                    insertion += sourceTab.Rows[i]["column_name"] + " " + sourceTab.Rows[i]["data_type_name"]; //add column name and type
                    if (sourceTab.Rows[i]["data_type_name"].ToString().ToUpper() == "VARCHAR")
                        insertion += "(" + sourceTab.Rows[i]["column_size"] + ")"; //add maximal column length in case it's variable
                    insertion += ", ";
                    repop += sourceTab.Rows[i]["column_name"] + ", "; //add column name
                }
                insertion += columns[j + 1] + " " + types[j + 1];
                repop += columns[j + 1];
            }
            for (int i = indeces[indeces.Count() - 1]; i < sourceTab.Rows.Count; i++)
            {
                insertion += ", " +sourceTab.Rows[i]["column_name"] + " " + sourceTab.Rows[i]["data_type_name"]; //finish description
                repop += ", " + sourceTab.Rows[i]["column_name"]; //finish enumeration
                if (sourceTab.Rows[i]["data_type_name"].ToString().ToUpper() == "VARCHAR")
                    insertion += "(" + sourceTab.Rows[i]["column_size"] + ")";
            }


            /*foreach (DataRow dr in sourceTab.Rows)
            {
                if (i < indeces[j])
                {
                    
                }
                if (i == indeces[j])
                {
                    
                }
                if (i > indeces[j])
                {
                    if (j < indeces.Count()-1 && i < indeces[j + 1])
                            j++;
                    else {
                        insertion += ", " + dr["column_name"] + " " + dr["data_type_name"]; //finish description
                        repop += ", " + dr["column_name"]; //finish enumeration
                        if (dr["data_type_name"].ToString().ToUpper() == "VARCHAR")
                            insertion += "(" + dr["column_size"] + ")";
                        i++;
                    }
                }
                 //the right place is reached
            }*/
           
            String tmpTbl = source + "0";
            CopyTables(source, tmpTbl);
            DB2Command dropCmd = new DB2Command("drop table " + source + ";", conn);
            try
            {
                dropCmd.ExecuteNonQuery();
            }
            catch (InvalidOperationException ioe)
            {
                Console.WriteLine(dropCmd.CommandText);
                Console.WriteLine(ioe.Message);
            }
            catch (DB2Exception db2e)
            {
                Console.WriteLine(dropCmd.CommandText);
                Console.WriteLine(db2e.Message);
            }
            DB2Command addCol = new DB2Command("alter table " + tmpTbl + " add " + columns[0] + " " + types[0], conn);
            try
            {
                addCol.ExecuteNonQuery();
            }
            catch (InvalidOperationException ioe)
            {
                Console.WriteLine(addCol.CommandText);
                Console.WriteLine(ioe.Message);
            }
            catch (DB2Exception db2e)
            {
                Console.WriteLine(addCol.CommandText);
                Console.WriteLine(db2e.Message);
            }
            DB2Command restoreCmd = new DB2Command("create table "+source+ "(" + insertion + ");", conn);
            try
            {
                Console.WriteLine(restoreCmd.CommandText);
                addCol.ExecuteNonQuery();
            }
            catch (InvalidOperationException ioe)
            {
                Console.WriteLine(restoreCmd.CommandText);
                Console.WriteLine(ioe.Message);
            }
            catch (DB2Exception db2e)
            {
                Console.WriteLine(restoreCmd.CommandText);
                Console.WriteLine(db2e.Message);
            }
            DB2Command repopCmd = new DB2Command("insert into " + source + "(select " + repop + " from " + tmpTbl + ");", conn);
            try
            {
                repopCmd.ExecuteNonQuery();
            }
            catch (InvalidOperationException ioe)
            {
                Console.WriteLine(ioe.Message);
            }
            catch (DB2Exception db2e)
            {
                Console.WriteLine(db2e.Message);
            }
            DB2Command dropTmp = new DB2Command("drop table " + tmpTbl + ";", conn);
            try
            {
                dropTmp.ExecuteNonQuery();
            }
            catch (InvalidOperationException ioe)
            {
                Console.WriteLine(ioe.Message);
            }
            catch (DB2Exception db2e)
            {
                Console.WriteLine(db2e.Message);
            }
        }

        public int setPrimaryKey(String source, int n) 
        {
            DataTable sourceTab = conn.GetSchema(DB2MetaDataCollectionNames.Columns, new String[4] { null, null, source, null });
            String soughtAttr = sourceTab.Rows[n]["column_name"].ToString();
            DB2DataAdapter sourceAd = new DB2DataAdapter(new DB2Command("select "+soughtAttr+" from " + source + ";", conn));
            DataTable allRows = new DataTable();
            sourceAd.Fill(allRows);
            sourceAd=new DB2DataAdapter(new DB2Command("select distinct "+soughtAttr+" from "+source +" where not "+soughtAttr+"=null;",conn));
            DataTable distCheck=new DataTable();
            sourceAd.Fill(distCheck);
            if (!distCheck.Equals(allRows))
            {
                Console.WriteLine("Primary key not set " + source + ": attribute not distinct or assigned null value.");
                return 1;
            }
            int i = 0;
            String creation="";
            foreach (DataRow dc in sourceTab.Rows)
            {
                creation += ", "+dc["column_name"] + " " + dc["data_type_name"];
                if (dc["data_type_name"].ToString()=="VARCHAR")
                    creation += "(" + dc["column_size"] + ")";
                i++;
                if (i == n)
                    creation += " not null primary key";
            }
            creation = creation.Substring(2);
            String tmpTbl = source + "0";
            CopyTables(source, tmpTbl);
            DB2Command dropCmd = new DB2Command("drop table " + tmpTbl + ";", conn);
            try
            {
                dropCmd.ExecuteNonQuery();
            }
            catch (InvalidOperationException ioe)
            {
                Console.WriteLine(dropCmd.CommandText);
                Console.WriteLine(ioe.Message);
            }
            catch (DB2Exception db2e)
            {
                Console.WriteLine(dropCmd.CommandText);
                Console.WriteLine(db2e.Message);
            }
            DB2Command create= new DB2Command("create table "+source+" ("+creation+");", conn);
            try
            {
                create.ExecuteNonQuery();
            }
            catch (InvalidOperationException ioe)
            {
                Console.WriteLine(create.CommandText);
                Console.WriteLine(ioe.Message);
            }
            catch (DB2Exception db2e)
            {
                Console.WriteLine(create.CommandText);
                Console.WriteLine(db2e.Message);
            }
            DB2Command populate = new DB2Command("insert into " + source + " (select * from " +tmpTbl + ");", conn);
            try
            {
                populate.ExecuteNonQuery();
            }
            catch (InvalidOperationException ioe)
            {
                Console.WriteLine(ioe.Message);
            }
            catch (DB2Exception db2e)
            {
                Console.WriteLine(db2e.Message);
            }
            DB2Command dropTmp = new DB2Command("drop table " + tmpTbl + ";", conn);
            try
            {
                dropTmp.ExecuteNonQuery();
            }
            catch (InvalidOperationException ioe)
            {
                Console.WriteLine(ioe.Message);
            }
            catch (DB2Exception db2e)
            {
                Console.WriteLine(db2e.Message);
            }
            return 0;
        }
        /*public int setForeignKey(String source, int n, String refTbl, String refCol) { 
            DataTable sourceTab = conn.GetSchema(DB2MetaDataCollectionNames.Columns, new String[4] { null, null, source, null });
            String soughtAttr = sourceTab.Rows[n]["column_name"].ToString();
            DB2DataAdapter sourceAd = new DB2DataAdapter(new DB2Command("select "+soughtAttr+" from " + source + ";", conn));
            DataTable allRows = new DataTable();
            sourceAd.Fill(allRows);
            sourceAd=new DB2DataAdapter(new DB2Command("select "+soughtAttr+" from "+source + " where not "+soughtAttr+"=null;",conn));
            DataTable distCheck=new DataTable();
            sourceAd.Fill(distCheck);
            if (!distCheck.Equals(allRows))
            {
                Console.WriteLine("Foreign key not set " + source + ": attribute assigned null value.");
                return 1;
            }
            int i = 0;
            String creation="";
            foreach (DataRow dc in sourceTab.Rows)
            {
                creation += ", "+dc["column_name"] + " " + dc["data_type_name"];
                if (dc["data_type_name"].ToString()=="VARCHAR")
                    creation += "(" + dc["column_size"] + ")";
                i++;
                if (i == n)
                    creation += " not null foreign key references "+refTbl+"."+refCol;
            }
            creation = creation.Substring(2);
            String tmpTbl = source + "0";
            CopyTables(source, tmpTbl);
            DB2Command dropCmd = new DB2Command("drop table " + tmpTbl + ";", conn);
            try
            {
                dropCmd.ExecuteNonQuery();
            }
            catch (InvalidOperationException ioe)
            {
                Console.WriteLine(dropCmd.CommandText);
                Console.WriteLine(ioe.Message);
            }
            catch (DB2Exception db2e)
            {
                Console.WriteLine(dropCmd.CommandText);
                Console.WriteLine(db2e.Message);
            }
            DB2Command create= new DB2Command("create table "+source+" ("+creation+");", conn);
            try
            {
                create.ExecuteNonQuery();
            }
            catch (InvalidOperationException ioe)
            {
                Console.WriteLine(create.CommandText);
                Console.WriteLine(ioe.Message);
            }
            catch (DB2Exception db2e)
            {
                Console.WriteLine(create.CommandText);
                Console.WriteLine(db2e.Message);
            }
            DB2Command populate = new DB2Command("insert into " + source + " (select * from " +tmpTbl + ");", conn);
            try
            {
                populate.ExecuteNonQuery();
            }
            catch (InvalidOperationException ioe)
            {
                Console.WriteLine(ioe.Message);
            }
            catch (DB2Exception db2e)
            {
                Console.WriteLine(db2e.Message);
            }
            DB2Command dropTmp = new DB2Command("drop table " + tmpTbl + ";", conn);
            try
            {
                dropTmp.ExecuteNonQuery();
            }
            catch (InvalidOperationException ioe)
            {
                Console.WriteLine(ioe.Message);
            }
            catch (DB2Exception db2e)
            {
                Console.WriteLine(db2e.Message);
            }
            return 0;
        }*/
    }
}
