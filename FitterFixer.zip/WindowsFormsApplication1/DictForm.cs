﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IBM.Data.DB2;
using IBM.Data.DB2Types;

namespace WindowsFormsApplication1
{
    public partial class DictForm : Form
    {
        DB2Connection conn;
        public String wordTbl;
        public String synTbl;
        public String[] wordRef;
        public String wordCol;
        public String synCol;
        public DictForm()
        {
            InitializeComponent();
        }

        public DictForm(DB2Connection db2c)
        {
            InitializeComponent();
            conn = db2c;
            wordRef = new String[2];
            DataTable dt = db2c.GetSchema(DB2MetaDataCollectionNames.Tables);
            foreach (DataRow dr in dt.Rows)
            {
                //Console.WriteLine(dr["table_name"]);
                if (!dr["table_schema"].ToString().StartsWith("SYS"))
                {
                    comboBox4.Items.Add(dr["table_name"]);
                    comboBox3.Items.Add(dr["table_name"]);
                }
            }
            dataGridView1.AutoGenerateColumns = true;
            dataGridView2.AutoGenerateColumns = true;
        }

        private void DictForm_Load(object sender, EventArgs e)
        {
            
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox2.Items.Clear();
            comboBox5.Items.Clear();
            if (!conn.IsOpen)
                conn.Open();
            DataTable dt=conn.GetSchema(DB2MetaDataCollectionNames.Columns, new String[4]{null,null,comboBox3.SelectedItem.ToString(),null});
            DataTable words = new DataTable();
            DB2DataAdapter db2a = new DB2DataAdapter("select * from " + comboBox3.SelectedItem.ToString() + " fetch first 10 rows only;", conn);
            db2a.Fill(words);
            dataGridView2.DataSource = words;
            foreach (DataRow dr in dt.Rows)
            {
                comboBox2.Items.Add(dr["column_name"]);
                comboBox5.Items.Add(dr["column_name"]);
            }
            wordTbl = comboBox3.SelectedItem.ToString();
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();
            comboBox6.Items.Clear();
            DataTable syns = new DataTable();
            DB2DataAdapter db2a = new DB2DataAdapter("select * from " + comboBox4.SelectedItem.ToString() + " fetch first 10 rows only;", conn);
            db2a.Fill(syns);
            dataGridView1.DataSource = syns;
            if (!conn.IsOpen)
                conn.Open();
            DataTable dt = conn.GetSchema(DB2MetaDataCollectionNames.Columns, new String[4] { null, null, comboBox4.SelectedItem.ToString(), null });
            foreach (DataRow dr in dt.Rows)
            {
                comboBox1.Items.Add(dr["column_name"]);
                comboBox6.Items.Add(dr["column_name"]);
            }
            synTbl = comboBox4.SelectedItem.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Visible = false;
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            wordRef[0] = comboBox2.SelectedItem.ToString();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            wordRef[1] = comboBox1.SelectedItem.ToString();
        }

        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
            wordCol = comboBox5.SelectedItem.ToString();
        }

        private void comboBox6_SelectedIndexChanged(object sender, EventArgs e)
        {
            synCol = comboBox6.SelectedItem.ToString();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            FileDialog fd = new OpenFileDialog();
            fd.Filter = "Comma Separated Values|*.csv";
            String dataCSV = "";
            while (!fd.FileName.EndsWith(".csv"))
            {
                if (fd.ShowDialog() == DialogResult.OK)
                {
                    dataCSV = fd.FileName;
                    textBox1.Text = fd.FileName.Split('\\').Last().Substring(0, fd.FileName.Split('\\').Last().Length - 4);
                }
            }
            CSVParser parser = new CSVParser();
            parser.parse(fd.FileName, conn);
            DataTable dt = new DataTable();
            DB2DataAdapter ad = new DB2DataAdapter("select * from " + fd.FileName.Split('\\').Last().Substring(0, fd.FileName.Split('\\').Last().Length - 4) + " fetch first 10 rows only;", conn);
            ad.Fill(dt);
            dataGridView2.DataSource = dt;
            wordTbl = fd.FileName.Split('\\').Last().Substring(0, fd.FileName.Split('\\').Last().Length - 4);
            comboBox3.Items.Add(wordTbl.ToUpper());
            comboBox3.SelectedIndex = comboBox4.Items.Count - 1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FileDialog fd = new OpenFileDialog();
            fd.Filter = "Comma Separated Values|*.csv";
            String dataCSV = "";
            while (!fd.FileName.EndsWith(".csv"))
            {
                if (fd.ShowDialog() == DialogResult.OK)
                {
                    dataCSV = fd.FileName;
                    textBox2.Text = fd.FileName.Split('\\').Last().Substring(0, fd.FileName.Split('\\').Last().Length - 4);
                }
            }
            CSVParser parser = new CSVParser();
            parser.parse(fd.FileName, conn);
            DataTable dt = new DataTable();
            DB2DataAdapter ad = new DB2DataAdapter("select * from " + fd.FileName.Split('\\').Last().Substring(0, fd.FileName.Split('\\').Last().Length - 4) + " fetch first 10 rows only;", conn);
            ad.Fill(dt);
            dataGridView1.DataSource = dt;
            synTbl = fd.FileName.Split('\\').Last().Substring(0, fd.FileName.Split('\\').Last().Length - 4);
            comboBox4.Items.Add(synTbl.ToUpper());
            comboBox4.SelectedIndex = comboBox4.Items.Count - 1;
        }
    }
}
