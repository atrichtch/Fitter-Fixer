﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IBM.Data.DB2;
using IBM.Data.DB2Types;

namespace WindowsFormsApplication1
{
    public partial class Form9 : Form
    {
        DataTable solutions;
        String tblName;
        String attr;
        String categMatch;
        DB2Connection db;
        int errInd;
        public Form9()
        {
            InitializeComponent();
        }

        public Form9(DB2Connection db, DataTable dt, String tblName, String attr, int index, String categMatch)
        {
            InitializeComponent();
            this.tblName = tblName;
            this.attr = attr;
            this.db = db;
            this.categMatch = categMatch;
            errInd = index;
            solutions = dt;
            dataGridView1.AutoGenerateColumns = true;
            dataGridView1.DataSource = dt;
            dataGridView1.Columns[1].Width = 400;
            foreach (DataRow dr in dt.Rows)
            {
                domainUpDown1.Items.Add(dr[0].ToString());
            }
        }


        

        private void richTextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void domainUpDown1_SelectedItemChanged(object sender, EventArgs e)
        {
            for (int i=0; i<dataGridView1.Rows.Count; i++)
                dataGridView1.Rows[i].DefaultCellStyle.BackColor = Color.White;
            if (domainUpDown1.SelectedIndex>=0 && domainUpDown1.SelectedIndex<dataGridView1.Rows.Count)
                dataGridView1.Rows[domainUpDown1.SelectedIndex].DefaultCellStyle.BackColor = Color.Red;
            richTextBox2.Text = dataGridView1.Rows[domainUpDown1.SelectedIndex].Cells[0].Value.ToString();
            richTextBox1.Text = dataGridView1.Rows[domainUpDown1.SelectedIndex].Cells[1].Value.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int totalErrs;
            int correctErrs;
            DataTable errCnt = new DataTable();
            DB2DataAdapter countAd = new DB2DataAdapter("select count (*) from " + tblName + " where categ_err_"+errInd+"=1 and not "+attr+"='';",db);
            countAd.Fill(errCnt);
            totalErrs = Int32.Parse(errCnt.Rows[0][0].ToString());
            foreach (DataRow dr in solutions.Rows)
            {
                String[] replacement=dr["suggestion"].ToString().Split('\'');
                String repl="";
                for (int k = 0; k < replacement.Length; k++)
                    repl += replacement[k];
                DB2Command db2c=new DB2Command("update "+tblName+" set "+attr+"='"+repl+"' where lower("+attr+")='"+dr["entry"]+"';",db);
                try
                {
                    db2c.ExecuteNonQuery();
                }
                catch (DB2Exception x)
                {
                    Console.WriteLine(db2c.CommandText);
                    Console.WriteLine(x.Message);
                }
                catch (InvalidOperationException x)
                {
                    Console.WriteLine(db2c.CommandText);
                    Console.WriteLine(x.Message);
                }
            }
            errCnt = new DataTable();
            DB2Command comm = new DB2Command("", db);
            comm.CommandText = "update " + tblName + " set categ_err_" + errInd + "=0 where not "
                    + attr + "='' and exists (select * from " + categMatch + " where ";
            DataTable dtbl = db.GetSchema(DB2MetaDataCollectionNames.Columns, new String[4] { null, null, categMatch, null });
            String[] matCols = new String[dtbl.Rows.Count];
            int i = 0;
            foreach (DataRow dr in dtbl.Rows)
            {
                matCols[i] = dr["column_name"].ToString();
                i++;
            }
            for (int j = 0; j < dtbl.Rows.Count; j++)
            {
                comm.CommandText += "upper(" + categMatch + "." + matCols[j] + ")=upper(" +
                    tblName + "." + attr + ") or ";
            }
            comm.CommandText = comm.CommandText.Substring(0, comm.CommandText.Length - 4) + ");";
            try
            {
                comm.ExecuteNonQuery();
                Console.Write(comm.CommandText);
                Console.WriteLine("");
            }
            catch (InvalidOperationException excpt)
            {
                Console.WriteLine(excpt.Message);
                Console.Write(comm.CommandText);
                Console.WriteLine("");
            }
            catch (DB2Exception db2e2)
            {
                Console.WriteLine(db2e2.Message);
                Console.Write(comm.CommandText);
                Console.WriteLine("");
            }
            DB2DataAdapter countAd2 = new DB2DataAdapter("select count (*) from " + tblName + " where categ_err_" + errInd + "=1 and not " + attr + "='';", db);
            countAd2.Fill(errCnt);
            correctErrs =totalErrs-Int32.Parse(errCnt.Rows[0][0].ToString());
            MessageBox.Show("Total errors: "+totalErrs+"\nCorrected: "+correctErrs);
        }
    }
}
