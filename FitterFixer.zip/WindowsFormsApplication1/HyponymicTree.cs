﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Text;
using IBM.Data.DB2;
using IBM.Data.DB2Types;

namespace WindowsFormsApplication1
{
    class HyponymicTree
    {
        private HypoTreeNode root;
        private ClassTreeNode host;
        private int[] pivot;
       
        public HyponymicTree(ClassTreeNode host)
        {
            this.host = host;
        }
        public HypoTreeNode getRoot()
        {
            return root;
        }
        public void populate(DB2Connection db2c, String wordTbl, String hyponymTbl, String entry)
        {
            DataTable curHypernyms = new DataTable();
            DataTable nextHypernyms = new DataTable();
            /*DB2DataAdapter ada = new DB2DataAdapter("select word from "+wordTbl+" where word_id in (select word_id from "+hyponymTbl
                +" where hyponym_id in (select word_id from "+wordTbl+" where word='"+entry+"'));", db2c);*/
            DB2DataAdapter idAda=new DB2DataAdapter("select word_id from nindex where word='"+entry+"';",db2c);
            idAda.Fill(nextHypernyms);
            pivot[0] = 0;
            while (nextHypernyms.Rows.Count != 0)
            {
                pivot[0]++;
                curHypernyms = nextHypernyms;
            }
            root = new HypoTreeNode(curHypernyms.Rows[0].ToString(), db2c, host);
        }
        public void populate(DB2Connection db2c, String word_id, ClassTreeNode host)
        {
            root = new HypoTreeNode(word_id, db2c, host);
        }
        public double score()
        {
            return root.score();
        }
    }
}
