﻿/*@author Alex Trichtchenko
 * Not for commercial use
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Text;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using IBM.Data.DB2;
using IBM.Data.DB2Types;
using System.Text.RegularExpressions;

namespace WindowsFormsApplication1
{
    class CSVParser
    {
        public void parse(String fileName, DB2Connection localEstab) {
            if (fileName == "")
            {
                FileDialog fd = new OpenFileDialog();
                fd.Filter = "Comma Separated Values|*.csv";
                if (fd.ShowDialog() == DialogResult.OK)
                    fileName = fd.FileName;
            }
            
            String tblName = fileName;
            Console.WriteLine("now parsing "+tblName);
            StreamReader reader = new StreamReader(fileName, Encoding.GetEncoding("windows-1252"));
            try
            {
                String curLn = reader.ReadLine();
                //int nChars = 0;
                //int[] splitInds;

                bool quotesMatched = true;
                Console.WriteLine(curLn);
                String[] attribs = curLn.Split(',');
                String[] finalAttrs = new String[attribs.Length];
                int soFar = 0;
                for (int i = 0; i < attribs.Length; i++)
                {
                    finalAttrs[soFar] = attribs[i];
                    Console.WriteLine(attribs[i]);
                    if (attribs[i].StartsWith("\""))
                    {
                    while (!attribs[i].EndsWith("\"") && i < attribs.Length)
                        {
                          i++;
                          finalAttrs[soFar] = finalAttrs[soFar] + attribs[i];
                        }
                    }
                    soFar++;
                    Console.WriteLine(soFar);
                }
                String[,] data = new String[100, soFar];
                Console.WriteLine(data.Length);
                int nLns = 1;
                string[] vtypes = new string[soFar];
                bool[] nums = new bool[soFar];
                bool[] bigints = new bool[soFar];
                bool[] dates = new bool[soFar];
                bool[] timeStamps = new bool[soFar];
                bool[] texts = new bool[soFar];

                for (int i = 0; i < soFar; i++)
                {
                    vtypes[i] = "";
                    Console.WriteLine(i);
                    bigints[i] = true;
                    nums[i] = true;
                }
                curLn = reader.ReadLine();
                int[] maxLgt = new int[soFar];
                for (int i = 0; i < soFar; i++)
                    maxLgt[i] = 0;
                while (curLn != null)
                {
                    if (nLns == 10)
                        Console.WriteLine(curLn);
                    if (curLn.Contains("\u2015")) {
                        String[] emSplit = curLn.Split('\u2015');
                        curLn="";
                        for (int i = 0; i < emSplit.Length; i++)
                            curLn += emSplit[i] + "\u2014";
                    }
                    //Console.WriteLine(curLn);
                    quotesMatched = true;
                    String[] entries = curLn.Split(',');
                    if (nLns == data.Length / soFar + 1)
                    {
                        String[,] temp = new String[data.Length / soFar, soFar];
                        for (int i = 0; i < data.Length / soFar; i++)
                            for (int j = 0; j < soFar; j++)
                                temp[i, j] = data[i, j];
                        data = new String[2 * data.Length / soFar, soFar];
                        for (int i = 0; i < temp.Length / soFar; i++)
                            for (int j = 0; j < soFar; j++)
                                data[i, j] = temp[i, j];
                    }
                    String[] finalEntries = new String[finalAttrs.Length];
                    int nEntr = 0;
                    Boolean badLine = false;
                    quotesMatched = true;
                    bool firstAfterQuotes = false;
                    for (int i = 0; i < entries.Length; i++)
                    {
                        if (nEntr < soFar - 1)
                        {
                            while (i == entries.Length - 1)
                            {
                                curLn = curLn + reader.ReadLine();
                                entries = curLn.Split(',');
                                Console.WriteLine(curLn);
                            }
                        }
                        finalEntries[nEntr] = entries[i];
                        if (entries[i].StartsWith("\""))
                        {
                            firstAfterQuotes = true;
                            quotesMatched = false;
                            finalEntries[nEntr] = finalEntries[nEntr].Substring(1);
                            while (i < entries.Length && !quotesMatched)
                            {
                                if (entries[i].Length == 1 && firstAfterQuotes)
                                {
                                    finalEntries[nEntr] = finalEntries[nEntr] + "," + entries[i + 1];
                                    i++;
                                    continue;
                                }
                                string quotes = "\"";
                                int quotesSoFar;
                                for (quotesSoFar = 0; entries[i].EndsWith(quotes); quotesSoFar++)
                                    quotes += "\"";
                                if (quotesSoFar % 2 == 1) break;
                                else if (i < entries.Length - 1)
                                {
                                    finalEntries[nEntr] = finalEntries[nEntr] + "," + entries[i + 1];
                                    //    Console.WriteLine("We are not updating current line");
                                    i++;
                                }
                                else if (!entries[i].EndsWith("\""))
                                {
                                    //    Console.WriteLine("We are updating current line");
                                    //    Console.WriteLine(entries[i]);
                                    if (curLn.EndsWith(" "))
                                        curLn = curLn + reader.ReadLine();
                                    else
                                        curLn=curLn+" "+reader.ReadLine();
                                    entries = curLn.Split(',');
                                    badLine = true;
                                }
                                firstAfterQuotes = false;
                            }
                            if (nEntr < soFar)
                                finalEntries[nEntr] = finalEntries[nEntr].Substring(0, finalEntries[nEntr].Length - 1);
                        }
                        nEntr++;
                    }
                    if (nEntr != soFar)
                    {
                        Console.WriteLine("Parsing error " + nEntr + "," + soFar);
                        Console.WriteLine(curLn);
                        break;
                    }
                    /*if (badLine && nLns > 6000)
                        Console.WriteLine(curLn);*/
                    for (int i = 0; i < soFar; i++)
                    {
                        data[nLns - 1, i] = finalEntries[i];
                        if (finalEntries[i].Length > maxLgt[i])
                            maxLgt[i] = finalEntries[i].Length;
                        //    Console.WriteLine(finalEntries[i]);
                    }
                    for (int i = 0; i < soFar; i++)
                    {
                        if (bigints[i])
                        {
                            for (int j = 0; j < finalEntries[i].Length && bigints[i]; j++)
                            {
                                if (finalEntries[i].ToCharArray()[j] >= '0' && finalEntries[i].ToCharArray()[j] <= '9')
                                    bigints[i] = true;
                                else
                                {
                                    bigints[i] = false;
                                    nums[i] = true;
                                }
                            }
                        }
                        else if (nums[i])
                        {
                            String[] mantFrac = finalEntries[i].Split('.');
                            if (mantFrac.Length > 2) nums[i] = false;
                            for (int j = 0; j < mantFrac.Length && nums[i]; j++)
                            {
                                for (int k = 0; k < mantFrac[j].Length && nums[i]; k++)
                                {
                                    if (mantFrac[j].ToCharArray()[k] >= '0' && mantFrac[j].ToCharArray()[k] <= '9')
                                        nums[i] = true;
                                    else
                                    {
                                        nums[i] = false;
                                        dates[i] = true;
                                        if (i >= 12)
                                        {
                                            Console.WriteLine(finalEntries[i]);
                                            Console.Write(finalAttrs[i]);
                                            Console.Write(" now false\n");
                                        }
                                    }
                                }
                            }
                        }
                        else if (dates[i])
                        {
                            try
                            {
                                System.DateTime dt = System.DateTime.Parse(finalEntries[i]);

                            }
                            catch
                            {
                                dates[i] = false;
                                timeStamps[i] = true;
                            }
                        }
                        else if (timeStamps[i])
                        {
                            try
                            {
                                System.DateTime dt = System.DateTime.ParseExact(finalEntries[i], "yyyy-MM-dd HH:mm tt",null);
                            }
                            catch
                            {
                                timeStamps[i] = false;
                                texts[i] = true;
                            }
                        }
                    }
                    nLns++;
                    curLn = reader.ReadLine();
                }
                Console.WriteLine("Total lines: " + nLns);
                for (int i = 0; i < soFar; i++)
                    if (maxLgt[i] >= 200) maxLgt[i] += 50;
                    else maxLgt[i] += 10;
                for (int i = 0; i < soFar; i++)
                    if (bigints[i]) vtypes[i] = "bigint";
                    else if (nums[i]) vtypes[i] = "num";
                    else if (dates[i]) vtypes[i] = "date";
                    else if (timeStamps[i]) vtypes[i] = "timestamp";
                    else vtypes[i] = "char";
                for (int i = 0; i < nLns - 1; i++)
                    for (int j = 0; j < soFar; j++)
                        if (vtypes[j] == "num" || vtypes[j] == "date" || vtypes[j]=="bigint")
                            if (data[i, j] == "")
                                data[i, j] = "null";
                String shrtTblName = tblName.Split('\\').Last();
                shrtTblName = shrtTblName.Substring(0, shrtTblName.Length - 4);
                //comboBox2.Text = shrtTblName;
                String sqlString = "create table " + shrtTblName;
                if (vtypes[0] == "char")
                    sqlString += " (" + finalAttrs[0] + " " + "varchar" + "(" + maxLgt[0].ToString() + ")";
                else
                    sqlString += " (" + finalAttrs[0] + " " + vtypes[0];  
                for (int i = 1; i < soFar; i++)
                    if (vtypes[i] == "char")
                        sqlString = sqlString + ", " + finalAttrs[i] + " " + "varchar(" + maxLgt[i] + ")";
                    else
                        sqlString = sqlString + ", " + finalAttrs[i] + " " + vtypes[i];
                sqlString = sqlString + ");";
                Console.WriteLine(sqlString);
                //change to dump into arbitrary user-defined database
                DB2Command db2c = new DB2Command(sqlString, localEstab);
                try
                {
                    //localEstab.Open();
                    Console.WriteLine("Connection done");
                    String sqlString2 = "";
                    DB2Command localComm = new DB2Command(sqlString2, localEstab);
                    try
                    {
                        db2c.ExecuteNonQuery();
                    }
                    catch (InvalidOperationException ex) {
                        Console.WriteLine("Can't create the table");
                        Console.WriteLine(ex.Message);
                    }
                    for (int i = 0; i < nLns - 1; i++)
                    {
                        if (i % 1000 == 0) Console.WriteLine(i);
                        sqlString2 = "insert into " + shrtTblName + " values (";
                        if (vtypes[0].Equals("char"))
                        {
                            if (data[i, 0].Contains('\''))
                            {
                                String[] temp = data[i, 0].Split('\'');
                                sqlString2 += "'" + temp[0];
                                for (int j = 1; j < temp.Length; j++)
                                    sqlString2 += "''" + temp[j];
                                sqlString2 += "'";
                            }
                            else
                                sqlString2 += "'" + data[i, 0] + "'";
                        }
                        else if (vtypes[0].Equals("date"))
                            sqlString2 += "'" + System.DateTime.Parse(data[i, 0]).Year.ToString() + "-" + System.DateTime.Parse(data[i, 0]).Month.ToString() + "-" + System.DateTime.Parse(data[i, 0]).Day.ToString() + "'";
                        else if (vtypes[0].Equals("timestamp"))
                            sqlString2 += "'" + System.DateTime.Parse(data[i, 0]).Year.ToString() + "-" + System.DateTime.Parse(data[i, 0]).Month.ToString() + "-" + System.DateTime.Parse(data[i, 0]).Day.ToString() + "-"+System.DateTime.Parse(data[i,0]).Hour.ToString()+"."+System.DateTime.Parse(data[i,0]).Minute.ToString()+"."+System.DateTime.Parse(data[i,0]).Second.ToString()+"."+System.DateTime.Parse(data[i,0]).Millisecond.ToString()+"000"+"'"; 
                        else
                            sqlString2 += data[i, 0];
                        for (int j = 1; j < soFar; j++)
                        {
                            if (vtypes[j] == "char")
                            {
                                try
                                {
                                    if (data[i, j].Contains('\''))
                                    {
                                        String[] temp = data[i, j].Split('\'');
                                        //Console.WriteLine(data[i, j]);
                                        sqlString2 += ", '" + temp[0];
                                        for (int k = 1; k < temp.Length; k++)
                                            sqlString2 += "''" + temp[k];
                                        sqlString2 += "'";
                                    }
                                    else
                                        sqlString2 += ", '" + data[i, j] + "'";
                                }
                                catch (IndexOutOfRangeException inde)
                                {
                                    Console.WriteLine("Something wrong with the line");
                                    Console.WriteLine(inde.Message);
                                }
                            }
                            else if (vtypes[j] == "date")
                                sqlString2 += ", '" + System.DateTime.Parse(data[i, j]).Year.ToString() + "-" + System.DateTime.Parse(data[i, j]).Month.ToString() + "-" + System.DateTime.Parse(data[i, j]).Day.ToString() + "'";
                            else
                                sqlString2 += ", " + data[i, j];
                        }
                        sqlString2 += ");";
                        localComm.CommandText = sqlString2;
                        try
                        {
                            localComm.ExecuteNonQuery();
                            if (i == 0)
                            {
                                Console.WriteLine(sqlString2);
                                Console.WriteLine("Success");
                            }
                        }
                        catch (InvalidOperationException excpt)
                        {
                            Console.WriteLine(sqlString2);
                            Console.WriteLine(excpt.Message);
                            break;
                        }
                        catch (DB2Exception db2e)
                        {
                            Console.WriteLine(sqlString2);
                            Console.WriteLine(db2e.Message);
                            break;
                        }
                    }
                    localEstab.Close();
                }
                catch (DB2Exception exc) {
                Console.WriteLine(exc.Message);
                }
            }
            catch { }

        }

    }
}
