﻿/*@author Alex Trichtchenko
 * Not for commercial use
 */

using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Data;
using System.Text;
using System.Text.RegularExpressions;
using IBM.Data.DB2;
using IBM.Data.DB2Types;

namespace WindowsFormsApplication1
{
    class ClassTreeNode
    {
        private String code; //use as key
        private String description; //use as value
        private ArrayList children;
        private String[,] alphaLists; //for use in string matching
        private String[] packets;
        private ArrayList[] occurrences;
        private ArrayList leaves;
        private Hashtable scores;
        private Hashtable hypoScores;
        private HyponymicTree[] hts;
        DB2Connection db;
        /*public ClassTreeNode(string s1, string s2)
        {
            this.code = s1;
            this.description = s2;
            this.packets = s2.Split(';');
            children = new ArrayList();
            occurrences=new ArrayList[packets.Length];
            for (int i = 0; i < packets.Length; i++)
                occurrences[i] = new ArrayList();
        }*/
        public ClassTreeNode(string s1, string s2,DB2Connection db)
        {
            this.code = s1;
            this.description = s2;
            this.packets = s2.Split(';');
            children = new ArrayList();
            occurrences=new ArrayList[packets.Length];
            for (int i = 0; i < packets.Length; i++)
                occurrences[i] = new ArrayList();
            this.db=db;
        }

        public ArrayList getChildren()
        {
            return children;
        }
        public ArrayList getSuccessors(int length)
        {//get successors of given code length
            ArrayList rightChildren = new ArrayList();
            for (int i = 0; i < children.Count; i++) {
                if (((ClassTreeNode)children[i]).code.Length == length)
                    rightChildren.Add((ClassTreeNode)children[i]);
                else if (((ClassTreeNode)children[i]).code.Length < length)
                    rightChildren.AddRange(((ClassTreeNode)children[i]).getSuccessors(length));
            }
            return rightChildren;
        }

        public ArrayList getLeaves()
        {
            if (leaves != null)
                return leaves;
            leaves = new ArrayList();
            if (children.Count == 0)
            {
                leaves.Add(this);
                return leaves;
            }
            for (int i = 0; i < children.Count; i++)
                leaves.AddRange(((ClassTreeNode)children[i]).getLeaves());
            return leaves;
        }

        public string getCode()
        {
            return code;
        }
        public string getDescription()
        {
            return description;
        }
        public void addChild(ClassTreeNode n)
        {
            children.Add(n);
        }

        public double score(String entry, String language)
        {
            double score=0;
            ArrayList negations = new ArrayList();
            if (language == "English")
            {
                negations.Add("not");
                negations.Add("except");
                negations.Add("but");
                negations.Add("other than");
            }
            if (language == "French")
            {
                negations.Add("non");
                negations.Add("pas");
                negations.Add("sauf");
                negations.Add("autre que");
                negations.Add("autres que");
            }
            String[] packets = this.description.Split(';'); //separate different lines if complex description
            for (int i = 0; i < packets.Count(); i++)
            {
                Regex curWordStart=new Regex("^"+entry.ToLower()+"[^a-zA-Z0-9]"); //occurs in the beginning
                Regex curPluralStart = new Regex("^" + plural(entry.ToLower()) + "[^a-zA-Z0-9]");
                Regex curWordMiddle = new Regex("[^a-zA-Z0-9]"+entry.ToLower()+"[^a-zA-Z0-9]"); //occurs in the middle
                Regex curPluralMiddle = new Regex("[^a-zA-Z0-9]" + plural(entry.ToLower()) + "[^a-zA-Z0-9]");
                Regex curWordEnd =new Regex("[^a-zA-Z0-9]" + entry.ToLower() + "$");//occurs at the end
                Regex curPluralEnd= new Regex("[^a-zA-Z0-9]" + plural(entry.ToLower()) + "$");
                if (packets[i].ToLower().Contains(entry.ToLower()) || packets[i].ToLower().Contains(plural(entry.ToLower())))
                {
                    if (curWordStart.IsMatch(packets[i].ToLower()) || curPluralStart.IsMatch(packets[i].ToLower())
                    || curWordMiddle.IsMatch(packets[i].ToLower()) || curPluralMiddle.IsMatch(packets[i].ToLower())
                    || curWordEnd.IsMatch(packets[i].ToLower()) || curPluralEnd.IsMatch(packets[i].ToLower())
                    || entry.ToLower() == packets[i].ToLower() || plural(entry.ToLower()) == packets[i].ToLower())
                        if (isLegalInclusion(packets[i].ToLower(), entry.ToLower(), language))
                        {
                            score = score + 1;
                            //break;
                        }
                }
            }
            /*if (entry=="Antiques" && code=="97")
                Console.WriteLine("Antiques scored "+score+" so far");*/
            for (int i = 0; i < children.Count; i++)
                score+=((ClassTreeNode)children[i]).score(entry,language) / children.Count; 
            return score;
        }

        public void alphabetize()
        {
            packets = this.description.Split(';'); //separate different lines if complex description
            String[] negations={ "not", "except", "other than", "but"};
            for (int i = 0; i < packets.Length; i++)
            {
                int firstNeg = getFirstNegation(negations, packets[i]);
                if (firstNeg > 0)
                    packets[i] = packets[i].Substring(0, firstNeg);
            }
            this.alphaLists = new String[packets.Length, this.description.Split(',', ' ').Length];
            for (int i = 0; i < packets.Length; i++)
            {
                String[] wordList = packets[i].Split(' ', ',');
                Array.Sort(wordList);
                for (int j = 0; j < wordList.Length; j++)
                    this.alphaLists[i,j] = wordList[j].ToLower();
            }
            for (int i = 0; i < children.Count; i++)
                ((ClassTreeNode)children[i]).alphabetize();
        }

        public int getFirstNegation(String[] negations, String s) {
            Regex[] negPatterns = new Regex[negations.Length];
            int[] firstMatches=new int[negations.Length];
            for (int i = 0; i < negPatterns.Length; i++)
            {
                negPatterns[i] = new Regex("[^a-zA-Z0-9]" + negations[i] + "[^a-zA-Z0-9]");
                firstMatches[i] = negPatterns[i].Match(s).Index;
            }
            int firstNeg = firstMatches[0];
            for (int i = 1; i < firstMatches.Length; i++)
                if (firstMatches[i] < firstNeg && firstMatches[i]>0) firstNeg = firstMatches[i];
            return firstNeg;
        }

        public void hashGen(String[] words)
        {
            //words assumed to have unique entries
            scores = new Hashtable();
            for (int i = 0; i < words.Length; i++)
                scores.Add(words[i], 0);
            for (int i = 0; i < packets.Length; i++)
            {
                ArrayList ownWords = new ArrayList();
                ArrayList enteredWords = new ArrayList();
                for (int j = 0; j < alphaLists.Length / packets.Length && alphaLists[i, j] != null; j++)
                    ownWords.Add(alphaLists[i, j]);
                for (int j = 0; j < words.Length; j++)
                    enteredWords.Add(words[j]);
                while (ownWords.Count>0 && enteredWords.Count>0)
                    switch (((String)enteredWords[0]).CompareTo((String)ownWords[0]))
                    {
                        case 1: ownWords.RemoveAt(0);
                            break;
                        case -1: enteredWords.RemoveAt(0);
                            break;
                        case 0:
                            {
                                occurrences[i].Add(enteredWords[0]);
                                scores[(String)enteredWords[0]]=(int)scores[(string)enteredWords[0]]+1;
                                ownWords.RemoveAt(0);
                                enteredWords.Remove(0);
                            }
                            break;
                    }
            }
            for (int i = 0; i < children.Count; i++)
                ((ClassTreeNode)children[i]).hashGen(words);
        }

        public double scoreHash(String entry)
        {
            double score = (int)scores[entry]+(int)scores[plural(entry)];
            for (int i = 0; i < children.Count; i++)
                score = score + (double)((ClassTreeNode)children[i]).scoreHash(entry)/children.Count;
            return score;
        }

        public double scoreHyponyms(String entry, String[] hyponyms)
        {
            //coeff is assumed to be between 0 and 1
            double score = scoreHash(entry);
            for (int i = 0; i < hyponyms.Length; i++)
                score += scoreHash(hyponyms[i])/hyponyms.Length;
            return score;
        }

        public double scoreHyponyms(String entry)
        {
            /*DB2DataAdapter idAda = new DB2DataAdapter("select word_id from nindex where word='" + entry + "';", db);
            DataTable idTbl = new DataTable();
            idAda.Fill(idTbl);
            String[] matchingIDs = new String[idTbl.Rows.Count];
            HyponymicTree[] hts = new HyponymicTree[matchingIDs.Length];*/
            hypoHashGen(entry);
            double score = 0;
            for (int i = 0; i < hts.Length; i++) {
                score += hts[i].score();
            }
            return score;
        }

        /*public void hashGen(String[] singulars, String[] plurals, String[] allEntries)
        {
            Hashtable scoresTmp = new Hashtable(allEntries.Length);
            packets = description.Split(';');
            for (int i = 0; i < packets.Length; i++)
            {
                int curEntry = 0;
                int curWord = 0;
                while (curEntry < allEntries.Length && curWord < alphaLists.Length / packets.Length && this.alphaLists[i, curWord] != null)
                {
                    double sc = 0;
                    while (allEntries[curEntry].CompareTo(alphaLists[i, curWord]) < 0)
                    {
                        if (!scoresTmp.Contains(allEntries[curEntry]))
                            scoresTmp.Add(allEntries[curEntry], sc);
                        curEntry++;
                    }
                    while (allEntries[curEntry] == alphaLists[i, curWord])
                    {
                        sc++;
                        curWord++;
                    }
                    if (!scoresTmp.Contains(allEntries[curEntry]))
                        scoresTmp.Add(allEntries[curEntry], sc);
                    curEntry++;
                }
            }
            scores = new Hashtable(singulars.Length);
            for (int i = 0; i < singulars.Length; i++)
            {
                double sc = (double)scoresTmp[singulars[i]] + (double)scoresTmp[plurals[i]];
                for (int j = 0; j < children.Count; j++)
                {
                    ((ClassTreeNode)children[j]).hashGen(singulars, plurals, allEntries);
                    sc = sc + ((double)((ClassTreeNode)children[j]).scores[singulars[i]])/children.Count;
                }
                if (!scores.Contains(singulars[i]))
                    scores.Add(singulars[i], sc);
            }
        }*/

        void hypoHashGen(String entry)
        {
            DB2DataAdapter idAda = new DB2DataAdapter("select word_id from nindex where word='" + entry + "';", db);
            DataTable idTbl = new DataTable();
            try
            {
                idAda.Fill(idTbl);
            }
            catch (InvalidOperationException e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine(idAda.SelectCommand.CommandText);
            }
            catch (DB2Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine(idAda.SelectCommand.CommandText);
            }
            String[] matchingIDs = new String[idTbl.Rows.Count];
            this.hts = new HyponymicTree[matchingIDs.Length];
            ArrayList hypoTmp = new ArrayList();
            for (int i = 0; i < matchingIDs.Length; i++)
            {
                matchingIDs[i] = idTbl.Rows[i][0].ToString();
                hts[i] = new HyponymicTree(this);
                hts[i].populate(db, matchingIDs[i], this);
            }
            for (int i = 0; i < hts.Length; i++)
                hypoTmp.AddRange(((HypoTreeNode)hts[i].getRoot()).getHyponyms());
            String[] hyponyms=new String[hypoTmp.Count];
            for (int i = 0; i < hypoTmp.Count; i++)
                hyponyms[i] = (String)hypoTmp[i];
            alphabetize();
            hashGen(hyponyms);
        }

        public bool isLegalInclusion(String phrase, String word, String language)
        {/* Makes sure the entry shows up before the first negation*/
            bool answer=false;
            ArrayList negations = new ArrayList();
            if (language == "English")
            {
                negations.Add("not");
                negations.Add("except");
                negations.Add("but");
                negations.Add("other than");
            }
            if (language == "French")
            {
                negations.Add("non");
                negations.Add("pas");
                negations.Add("sauf");
                negations.Add("autre que");
                negations.Add("autres que");
            }
           if (phrase.ToLower().Contains(word.ToLower()))
                for (int j = 0; j < negations.Count; j++)
                {
                    if (before(phrase.ToLower(), ((String)negations[j]).ToLower() + " ", word.ToLower()))
                    {//occurrence not counted if follows a negation in verbal description
                        answer=false;
                        break;
                    }
                    else
                        answer=true;
                }
            /*if ((word=="Antiques" || word=="antiques") && code=="97")
                Console.WriteLine(answer);*/
            return answer;
        }
        public String plural(String noun)
        {/*gets plural of most nouns; 
          * NOT for spell check, just to ensure the radicals match, not "racks" and "tracks"*/
            if (noun.EndsWith("s") || noun.EndsWith("ch") || noun.EndsWith("sh"))
                return noun + "es";
            if (noun.EndsWith("y"))
                return noun.Substring(0, noun.Length - 1) + "ies";
            return noun + "s";
        }
        public double scoreSynonyms(String[] words, String language)
        {
            double score = 0;
            for (int i = 0; i < words.Length; i++)
                score += this.score(words[i], language);
            return score;
        }
        public double scoreSynonyms(String entry, String[] words, String language)
        {
            double score = 0;
            for (int i = 0; i < words.Length; i++)
                score += this.score(words[i], language);
            score = 0.020 * score + this.score(entry,language);
            return score;
        }
        public double scoreSynonyms(String entry, String[] words, double synConf, String language)
        {
            double score = 0;
            for (int i = 0; i < words.Length; i++)
                score += this.score(words[i], language);
            score = synConf * score + this.score(entry,language);
            return score;
        }
        public bool before(String s, String s1, String s2)
        {//whether s1 occurs before s2 in s; not sure if exists in the package
            if (s.Contains(s1) && s.Contains(s2))
            {
                String tmp = string.Copy(s);
                int ind1 = 0;
                while (!tmp.StartsWith(s1))
                {
                    ind1++;
                    tmp = tmp.Substring(1);
                }
                tmp = string.Copy(s);
                int ind2 = 0;
                while (!tmp.StartsWith(s1))
                {
                    ind2++;
                    tmp = tmp.Substring(1);
                }
                return (ind1 < ind2);
            }
            return false;
        }
    }
}
