﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FitterFixer
{
    class MeronymicTree
    {
        //Meronyms are constituents; if one word is neither a meronym nor a hyponym of another, yet occurs in a successor node,
        //it most probably is a material used in the preparation of the utility described 
        //by the other word; thus inferring the information of its meaning
    }
}
